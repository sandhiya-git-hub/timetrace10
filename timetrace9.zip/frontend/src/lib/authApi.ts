import type { FieldErrors } from '@shared/validation/auth';

export class AuthApiError extends Error {
  status: number;
  code?: string;
  fieldErrors?: FieldErrors;

  constructor(message: string, status: number, code?: string, fieldErrors?: FieldErrors) {
    super(message);
    this.name = 'AuthApiError';
    this.status = status;
    this.code = code;
    this.fieldErrors = fieldErrors;
  }
}

const fallbackMessage = (status: number): string => {
  if (status === 404) {
    return 'The sign-in service was not found. If you are running the frontend separately, make sure the ChronoTrace API is running.';
  }
  if (status >= 500) return 'The server ran into a problem. Please try again in a moment.';
  return 'Something went wrong. Please try again.';
};

// POSTs JSON and always resolves with parsed JSON or throws AuthApiError. Non-JSON
// bodies (HTML error pages, empty 404s from a dev server without the API) become
// readable messages instead of "Unexpected token <" style parse errors.
export async function postAuthJson<T>(url: string, body: unknown): Promise<T> {
  let res: Response;
  const storedToken =
    typeof window !== 'undefined'
      ? localStorage.getItem('chronotrace_session_token') || sessionStorage.getItem('chronotrace_session_token')
      : null;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  };
  if (storedToken) {
    headers['Authorization'] = `Bearer ${storedToken}`;
    headers['X-Session-Token'] = storedToken;
  }

  try {
    res = await fetch(url, {
      method: 'POST',
      credentials: 'include',
      headers,
      body: JSON.stringify(body),
    });
  } catch {
    throw new AuthApiError(
      'Could not reach the ChronoTrace server. Check your connection and try again.',
      0
    );
  }

  const text = await res.text();
  let data: any = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = null;
    }
  }

  if (!res.ok) {
    throw new AuthApiError(
      data?.error || fallbackMessage(res.status),
      res.status,
      data?.code,
      data?.fieldErrors
    );
  }

  if (data === null) {
    throw new AuthApiError(fallbackMessage(res.status), res.status);
  }

  const token = data?.token || data?.sessionToken || data?.session?.token;
  if (token && typeof window !== 'undefined') {
    try {
      localStorage.setItem('chronotrace_session_token', token);
    } catch {}
  }

  return data as T;
}

export async function getAuthConfig(): Promise<{ googleClientId: string | null }> {
  try {
    const res = await fetch('/api/auth/config', { credentials: 'same-origin' });
    if (!res.ok) return { googleClientId: null };
    const data = await res.json();
    return { googleClientId: typeof data?.googleClientId === 'string' ? data.googleClientId : null };
  } catch {
    return { googleClientId: null };
  }
}
