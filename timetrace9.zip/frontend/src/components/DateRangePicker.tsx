import React, { useState, useRef, useEffect } from 'react';
import { Calendar, ChevronDown, Check, ArrowRight, RefreshCw } from 'lucide-react';

export type RangeType = 'today' | 'week' | 'custom';

export interface DateRangeSelection {
  type: RangeType;
  label: string;
  startDate?: string;
  endDate?: string;
}

interface DateRangePickerProps {
  value: DateRangeSelection;
  onChange: (selection: DateRangeSelection) => void;
  isLoading?: boolean;
}

const getTodayStr = () => new Date().toLocaleDateString('en-CA');
const getSevenDaysAgoStr = () => {
  const d = new Date();
  d.setDate(d.getDate() - 7);
  return d.toLocaleDateString('en-CA');
};

export const DateRangePicker: React.FC<DateRangePickerProps> = ({
  value,
  onChange,
  isLoading = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<RangeType>(value.type);
  const [customStart, setCustomStart] = useState<string>(value.startDate || getSevenDaysAgoStr());
  const [customEnd, setCustomEnd] = useState<string>(value.endDate || getTodayStr());
  const [validationError, setValidationError] = useState<string | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const handleSelectPreset = (type: 'today' | 'week') => {
    setActiveTab(type);
    setValidationError(null);
    if (type === 'today') {
      const today = getTodayStr();
      onChange({
        type: 'today',
        label: 'Today',
        startDate: today,
        endDate: today,
      });
    } else {
      onChange({
        type: 'week',
        label: 'Past 7 Days',
        startDate: getSevenDaysAgoStr(),
        endDate: getTodayStr(),
      });
    }
    setIsOpen(false);
  };

  const handleApplyCustom = () => {
    if (!customStart || !customEnd) {
      setValidationError('Please select both start and end dates.');
      return;
    }
    if (new Date(customStart) > new Date(customEnd)) {
      setValidationError('Start date must be before or equal to end date.');
      return;
    }
    setValidationError(null);
    onChange({
      type: 'custom',
      label: `${customStart} → ${customEnd}`,
      startDate: customStart,
      endDate: customEnd,
    });
    setIsOpen(false);
  };

  return (
    <div className="relative inline-block text-left" ref={containerRef}>
      {/* Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        disabled={isLoading}
        className="inline-flex items-center gap-2 bg-white hover:bg-slate-50 border border-slate-200/90 text-slate-800 text-xs font-medium px-3 py-2 rounded-lg shadow-2xs transition-colors cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-70"
      >
        <Calendar className="w-3.5 h-3.5 text-blue-600 shrink-0" />
        <span className="font-semibold text-slate-900">{value.label}</span>
        {isLoading ? (
          <RefreshCw className="w-3 h-3 text-blue-600 animate-spin ml-1" />
        ) : (
          <ChevronDown className="w-3 h-3 text-slate-400 ml-0.5" />
        )}
      </button>

      {/* Popover Dropdown */}
      {isOpen && (
        <div className="absolute right-0 mt-1.5 w-72 bg-white border border-slate-200 rounded-xl shadow-lg p-3 z-50 text-xs animate-in fade-in zoom-in-95 duration-100">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2 px-1">
            Select Date Range
          </div>

          {/* Preset Buttons */}
          <div className="space-y-1">
            <button
              onClick={() => handleSelectPreset('today')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left transition-colors cursor-pointer ${
                value.type === 'today'
                  ? 'bg-blue-50 text-blue-700 font-semibold'
                  : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              <div className="flex flex-col">
                <span>Today</span>
                <span className="text-[10px] text-slate-400 font-normal">October 9, 2026</span>
              </div>
              {value.type === 'today' && <Check className="w-3.5 h-3.5 text-blue-600" />}
            </button>

            <button
              onClick={() => handleSelectPreset('week')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left transition-colors cursor-pointer ${
                value.type === 'week'
                  ? 'bg-blue-50 text-blue-700 font-semibold'
                  : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              <div className="flex flex-col">
                <span>Past 7 Days</span>
                <span className="text-[10px] text-slate-400 font-normal">Oct 2, 2026 – Oct 9, 2026</span>
              </div>
              {value.type === 'week' && <Check className="w-3.5 h-3.5 text-blue-600" />}
            </button>
          </div>

          {/* Divider */}
          <div className="my-2 border-t border-slate-100" />

          {/* Custom Range Accordion */}
          <div>
            <button
              onClick={() => setActiveTab('custom')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left transition-colors cursor-pointer ${
                activeTab === 'custom'
                  ? 'bg-slate-100/80 font-semibold text-slate-900'
                  : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span>Custom Range</span>
              {value.type === 'custom' && <Check className="w-3.5 h-3.5 text-blue-600" />}
            </button>

            {activeTab === 'custom' && (
              <div className="mt-2.5 p-2.5 bg-slate-50 border border-slate-200/80 rounded-lg space-y-2">
                <div>
                  <label className="text-[10px] text-slate-500 font-medium block mb-1">
                    Start Date
                  </label>
                  <input
                    type="date"
                    value={customStart}
                    onChange={(e) => setCustomStart(e.target.value)}
                    max="2026-10-09"
                    className="w-full bg-white border border-slate-200 rounded px-2 py-1 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-slate-500 font-medium block mb-1">
                    End Date
                  </label>
                  <input
                    type="date"
                    value={customEnd}
                    onChange={(e) => setCustomEnd(e.target.value)}
                    max="2026-10-09"
                    className="w-full bg-white border border-slate-200 rounded px-2 py-1 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                {validationError && (
                  <div className="text-[10px] text-red-600 font-medium pt-0.5">
                    {validationError}
                  </div>
                )}

                <div className="pt-1 flex items-center justify-end gap-1.5">
                  <button
                    onClick={() => setIsOpen(false)}
                    className="px-2.5 py-1 text-xs text-slate-600 hover:bg-slate-200 rounded transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleApplyCustom}
                    className="inline-flex items-center gap-1 bg-blue-600 hover:bg-blue-700 text-white font-medium px-3 py-1 rounded text-xs transition-colors cursor-pointer shadow-2xs"
                  >
                    <span>Apply</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
