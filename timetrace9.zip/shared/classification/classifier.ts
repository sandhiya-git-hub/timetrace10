import type { IntentLabel, CanonicalCategory, ActivityCategory } from '../types/chronotrace.js';

export interface ActivityContext {
  url?: string;
  domain?: string;
  scrollCount?: number;
  clickCount?: number;
  keyCount?: number;
  activeDwellMs?: number;
  idleDwellMs?: number;
  isIdle?: boolean;
  isVisible?: boolean;
  revisited?: boolean;
  revisitCount?: number;
  durationSeconds?: number;
}

export interface ClassificationResult {
  category: CanonicalCategory;
  intent: IntentLabel;
  confidence: number;
  reason: string;
  task: string;
  isCollectorProcess?: boolean;
  engagementState?: 'active' | 'passive' | 'idle' | 'engaged' | 'open_only' | 'background';
}

export interface UserPreferenceRule {
  id: string;
  appPattern?: string;
  titlePattern?: string;
  domainPattern?: string;
  urlPattern?: string;
  category: ActivityCategory;
  intent: IntentLabel;
  createdAt: string;
}

// Regex patterns with word boundaries to prevent substring false-positives
const EDUCATIONAL_PATTERNS = [
  /\b(tutorial|tutorials|course|courses|lecture|lectures|lesson|lessons)\b/i,
  /\b(algorithm|algorithms|data\s+structure|data\s+structures|leetcode|neetcode)\b/i,
  /\b(dijkstra|graph\s+theory|dynamic\s+programming|binary\s+tree|sorting)\b/i,
  /\b(cs50|freecodecamp|fireship|3blue1brown|mit\s+opencourseware|coursera|udemy|edx)\b/i,
  /\b(crash\s+course|masterclass|bootcamp|workshop|webinar|deep\s+dive)\b/i,
  /\b(calculus|linear\s+algebra|differential\s+equations|discrete\s+math)\b/i,
  /\b(physics|chemistry|biology|neuroscience|biochemistry|quantum)\b/i,
  /\b(system\s+design|microservices|distributed\s+systems|cloud\s+architecture)\b/i,
  /\b(python|javascript|typescript|react|nextjs|nodejs|golang|rustlang|docker|kubernetes)\s+(tutorial|crash|guide|intro|explained|basics|architecture)\b/i,
  /\b(how\s+to\s+(build|code|program|implement|solve|deploy|design))\b/i,
  /\b(explained\s+simply|understanding\s+how|in-depth\s+analysis|study\s+guide)\b/i,
];

const RESEARCH_PATTERNS = [
  /\b(research\s+paper|arxiv|scholarly|literature\s+review|peer\s+reviewed)\b/i,
  /\b(methodology|abstract|citation|pubmed|biorxiv|ieee|acm)\b/i,
  /\b(documentation|docs|api\s+reference|specification|spec\s+sheet|rfcs?)\b/i,
];

const ENTERTAINMENT_PATTERNS = [
  /\b(official\s+video|official\s+music\s+video|lyric\s+video|lyrics|audio\s+track)\b/i,
  /\b(song|songs|remix|acoustic|karaoke|live\s+concert|soundtrack|ost|playlist)\b/i,
  /\b(trailer|teaser|official\s+trailer|teaser\s+trailer|sneak\s+peek)\b/i,
  /\b(movie|film|cinema|box\s+office|full\s+movie|movie\s+scene|film\s+clip)\b/i,
  /\b(episode\s+\d+|season\s+\d+|s\d+e\d+|series\s+finale|sitcom|anime|kdrama)\b/i,
  /\b(gameplay|playthrough|walkthrough\s+part|stream\s+highlights|twitch\s+stream)\b/i,
  /\b(valorant|minecraft|fortnite|gta\s+v|roblox|pubg|apex\s+legends|fifa|elden\s+ring)\b/i,
  /\b(prank|funny|comedy|standup|meme|memes|roast|reaction|parody|vlog)\b/i,
  /\b(netflix|disney\+|hulu|prime\s+video|hotstar|hbo|crunchyroll)\b/i,
  /\b(asmr|mukbang|shorts\s+feed|tiktok|reels|challenge)\b/i,
  /\b(highlights|cricket|ipl|fifa\s+world\s+cup|nba|football\s+highlights)\b/i,
];

const CODE_FILE_PATTERN = /\.(ts|tsx|js|jsx|py|go|rs|cpp|c|h|java|html|css|json|sql|md|yml|yaml|env|toml)\b/i;

const CODING_TASK_PATTERNS = [
  /\b(pull\s+request|pr\s*#|commit|merge\s+request|branch|code\s+review)\b/i,
  /\b(git\s+diff|git\s+push|git\s+status|debugger|breakpoints?|stack\s+trace)\b/i,
  /\b(refactor|bugfix|unit\s+test|integration\s+test|jest|vitest|pytest)\b/i,
  /\b(dockerfile|compose\.ya?ml|kubernetes\s+pod|helm\s+chart|webpack|esbuild)\b/i,
  /\b(syntax\s+error|nullpointerexception|typeerror|undefined\s+is\s+not)\b/i,
];

const WORK_TASK_PATTERNS = [
  /\b(sprint|backlog|jira|kanban|scrum|ticket|issue\s+tracking)\b/i,
  /\b(roadmap|milestone|deliverables?|quarterly\s+review|okrs?|kpi)\b/i,
  /\b(executive\s+summary|business\s+proposal|client\s+pitch|slide\s+deck)\b/i,
  /\b(invoice|procurement|timesheet|performance\s+review|1:1\s+notes)\b/i,
];

// Domains categorized by primary function
const STUDY_DOMAINS = [
  'coursera.org', 'udemy.com', 'edx.org', 'khanacademy.org', 'freecodecamp.org',
  'leetcode.com', 'neetcode.io', 'hackerrank.com', 'codecademy.com', 'duolingo.com',
  'cs50.harvard.edu', 'mitopencourseware.com', 'ocw.mit.edu', 'brilliant.org',
  'frontendmentor.io', 'exercism.org', 'scrimba.com'
];

const RESEARCH_DOMAINS = [
  'developer.mozilla.org', 'w3schools.com', 'stackoverflow.com', 'stackexchange.com',
  'docs.python.org', 'react.dev', 'nodejs.org', 'typescriptlang.org', 'rust-lang.org',
  'golang.org', 'go.dev', 'pkg.go.dev', 'docs.rs', 'pypi.org', 'npmjs.com', 'arxiv.org',
  'scholar.google.com', 'wikipedia.org', 'nature.com', 'science.org', 'researchgate.net',
  'mit.edu', 'stanford.edu', 'harvard.edu', 'geeksforgeeks.org', 'devdocs.io',
  'dev.to', 'hashnode.dev', 'docs.docker.com', 'kubernetes.io', 'angular.io',
  'vuejs.org', 'svelte.dev', 'nextjs.org', 'tailwindcss.com', 'prisma.io', 'drizzle.team',
  'vite.dev', 'vitejs.dev', 'vitest.dev', 'esbuild.github.io', 'webpack.js.org',
  'bun.sh', 'deno.land', 'deno.com', 'expressjs.com', 'fastify.io', 'nestjs.com',
  'lucide.dev', 'ui.shadcn.com', 'radix-ui.com', 'pubmed.ncbi.nlm.nih.gov'
];

const PLANNING_DOMAINS = [
  'calendar.google.com', 'keep.google.com', 'todoist.com', 'ticktick.com',
  'linear.app', 'atlassian.net', 'jira.com', 'trello.com', 'asana.com', 'monday.com',
  'notion.so', 'miro.com', 'lucidchart.com', 'app.diagrams.net', 'draw.io',
  'whimsical.com', 'airtable.com', 'coda.io', 'clickup.com', 'basecamp.com'
];

const COMMUNICATION_DOMAINS = [
  'slack.com', 'teams.microsoft.com', 'discord.com', 'mail.google.com',
  'outlook.live.com', 'outlook.office.com', 'web.whatsapp.com', 'web.telegram.org',
  'meet.google.com', 'zoom.us', 'gmail.com', 'loom.com', 'webex.com'
];

const ENTERTAINMENT_DOMAINS = [
  'netflix.com', 'twitch.tv', 'disneyplus.com', 'hulu.com', 'primevideo.com',
  'crunchyroll.com', 'spotify.com', 'soundcloud.com', 'steampowered.com', 'epicgames.com',
  'roblox.com', 'vimeo.com', 'hotstar.com', 'hbo.com', 'max.com',
  '9gag.com', 'buzzfeed.com'
];

const SOCIAL_PLATFORM_DOMAINS = [
  'reddit.com', 'instagram.com', 'twitter.com', 'x.com', 'facebook.com',
  'threads.net', 'tiktok.com', 'linkedin.com'
];

const UTILITY_DOMAINS = [
  'maps.google.com', 'weather.com', 'accuweather.com',
  'chase.com', 'bankofamerica.com', 'wellsfargo.com', 'ups.com', 'fedex.com',
  'usps.com', 'speedtest.net', 'fast.com', '1password.com', 'bitwarden.com',
  'lastpass.com'
];

export function extractDomainFromUrl(rawUrl?: string): string {
  if (!rawUrl) return '';
  try {
    const parsed = new URL(rawUrl.startsWith('http') ? rawUrl : `https://${rawUrl}`);
    return parsed.hostname.replace(/^www\./, '').toLowerCase();
  } catch {
    return '';
  }
}

export function normalizeCategory(cat: string): CanonicalCategory {
  switch (cat) {
    case 'Coding':
    case 'Deep Work':
    case 'Work':
      return 'Coding';
    case 'Study':
    case 'Research':
    case 'Learning':
    case 'Learning & Research':
    case 'Study & Research':
      return 'Study & Research';
    case 'Productivity & Planning':
    case 'Planning':
      return 'Productivity & Planning';
    case 'Entertainment':
    case 'Distraction':
    case 'DISTRACTION':
    case 'DISTRACTION_BREAK':
      return 'Entertainment';
    case 'Communication':
      return 'Communication';
    case 'Utilities':
    case 'Utility':
    case 'Utility / Admin':
    case 'Admin':
      return 'Utilities';
    default:
      return 'Unclassified';
  }
}

export function classifyActivity(
  appName: string,
  windowTitle: string,
  userPreferences: UserPreferenceRule[] = [],
  context?: ActivityContext
): ClassificationResult {
  const cleanApp = (appName || 'Active Window').trim();
  const cleanTitle = (windowTitle || cleanApp).trim();
  const appLower = cleanApp.toLowerCase();
  const titleLower = cleanTitle.toLowerCase();

  // Extract URL domain if available
  const domain = context?.domain || extractDomainFromUrl(context?.url) || '';
  const domainLower = domain.toLowerCase();
  const rawUrl = (context?.url || '').toLowerCase();

  // Calculate engagement signals
  const totalInteractions = (context?.clickCount || 0) + (context?.scrollCount || 0) + (context?.keyCount || 0);
  const activeMs = context?.activeDwellMs || 0;
  const idleMs = context?.idleDwellMs || 0;
  const totalDwellMs = (activeMs + idleMs) > 0 ? (activeMs + idleMs) : ((context?.durationSeconds || 2) * 1000);
  const dwellSec = Math.max(1, Math.round(totalDwellMs / 1000));

  const isIdle = Boolean(
    context?.isIdle ||
    (idleMs > 25000 && idleMs >= activeMs * 2 && totalInteractions === 0)
  );

  const hasSensorContext = Boolean(
    context && (
      context.clickCount !== undefined ||
      context.scrollCount !== undefined ||
      context.keyCount !== undefined ||
      context.activeDwellMs !== undefined ||
      context.idleDwellMs !== undefined ||
      context.isIdle !== undefined
    )
  );

  const isOpenOnly = hasSensorContext && !isIdle && totalInteractions === 0 && dwellSec <= 5 && activeMs < 3000;
  const isBackground = context?.isVisible === false;

  const engagementState: 'active' | 'passive' | 'idle' | 'engaged' | 'open_only' | 'background' = isIdle
    ? 'idle'
    : isBackground
    ? 'background'
    : isOpenOnly
    ? 'open_only'
    : totalInteractions >= 3 || activeMs > 8000
    ? 'engaged'
    : totalInteractions > 0 || activeMs > 3000 || dwellSec >= 10
    ? 'active'
    : 'passive';

  // 1. User manual preference rules (highest priority - preserve manual corrections)
  for (const pref of userPreferences) {
    let appMatch = true;
    let titleMatch = true;
    let domainMatch = true;
    let urlMatch = true;

    if (pref.appPattern) {
      appMatch = appLower.includes(pref.appPattern.toLowerCase());
    }
    if (pref.titlePattern) {
      titleMatch = titleLower.includes(pref.titlePattern.toLowerCase());
    }
    if (pref.domainPattern && domainLower) {
      domainMatch = domainLower.includes(pref.domainPattern.toLowerCase());
    }
    if (pref.urlPattern && rawUrl) {
      urlMatch = rawUrl.includes(pref.urlPattern.toLowerCase());
    }

    if (appMatch && titleMatch && domainMatch && urlMatch) {
      return {
        category: (pref.category as any) || normalizeCategory(pref.category),
        intent: pref.intent,
        confidence: 1.0,
        reason: 'User classification preference rule',
        task: `${cleanApp}: ${cleanTitle}`,
        engagementState,
      };
    }
  }

  // 2. ChronoTrace Agent / Collector Process Exclusion
  const isTerminalApp =
    appLower.includes('powershell') ||
    appLower.includes('terminal') ||
    appLower.includes('cmd') ||
    appLower === 'command prompt';

  const isCollectorTitle =
    titleLower.includes('chronotrace_agent.py') ||
    titleLower.includes('chronotrace_agent') ||
    titleLower.includes('agent.py') ||
    (titleLower.includes('chronotrace') && isTerminalApp);

  if (isCollectorTitle) {
    return {
      category: 'Utilities',
      intent: 'ADMIN',
      confidence: 1.0,
      reason: 'ChronoTrace collector background process (excluded from productivity metrics)',
      task: 'ChronoTrace Collector Agent',
      isCollectorProcess: true,
      engagementState: 'passive',
    };
  }

  // 3. Pure Idle State: when user is idle, classify as Idle engagement and category
  if (isIdle && totalInteractions === 0) {
    return {
      category: 'Idle',
      intent: 'UNKNOWN',
      confidence: 0.90,
      reason: 'Window open but user idle and inactive without keyboard, mouse, or scroll interaction',
      task: `Idle: ${cleanTitle}`,
      engagementState: 'idle',
    };
  }

  // 4. Open-Only Guardrail: Brief open with 0 interactions -> Unclassified
  if (isOpenOnly) {
    return {
      category: 'Unclassified',
      intent: 'UNKNOWN',
      confidence: 0.35,
      reason: 'Application or tab opened briefly without user engagement (insufficient dwell to classify activity)',
      task: `Opened: ${cleanTitle}`,
      engagementState: 'open_only',
    };
  }

  // 5. Google Calendar: explicitly classified as 'Productivity & Planning'
  const isGoogleCalendar =
    domainLower === 'calendar.google.com' ||
    domainLower.endsWith('.calendar.google.com') ||
    titleLower.includes('google calendar') ||
    (cleanApp.toLowerCase().includes('calendar') && titleLower.includes('google'));

  if (isGoogleCalendar) {
    return {
      category: 'Productivity & Planning',
      intent: 'ADMIN',
      confidence: 0.95,
      reason: 'Calendar scheduling and productivity planning',
      task: `Calendar: ${cleanTitle.replace(/- Google Calendar$/i, '').trim() || 'Schedule'}`,
      engagementState,
    };
  }

  // 6. Productivity & Planning Suites (Linear, Notion, Jira, Trello, Asana, Google Keep)
  const isPlanningDomain = PLANNING_DOMAINS.some((d) => domainLower === d || domainLower.endsWith(`.${d}`));
  const isPlanningTitle =
    titleLower.includes('google keep') ||
    titleLower.includes('linear.app') ||
    titleLower.includes('jira') ||
    titleLower.includes('trello') ||
    titleLower.includes('asana') ||
    titleLower.includes('monday.com') ||
    titleLower.includes('todoist') ||
    titleLower.includes('ticktick') ||
    appLower.includes('todoist');

  if (isPlanningDomain || isPlanningTitle) {
    return {
      category: 'Productivity & Planning',
      intent: 'DEEP_WORK',
      confidence: 0.92,
      reason: `Task planning, project management, or organization in ${domain || cleanApp}`,
      task: `Planning: ${cleanTitle}`,
      engagementState,
    };
  }

  // 7. Claude (claude.ai or native Claude app):
  // Must NOT automatically become Deep Work! Inspect conversation/project context.
  const isClaude =
    domainLower === 'claude.ai' ||
    domainLower.endsWith('.claude.ai') ||
    titleLower.includes('claude - ') ||
    titleLower.endsWith(' - claude') ||
    titleLower.includes('claude.ai') ||
    appLower === 'claude';

  if (isClaude) {
    const isCodingContext =
      CODE_FILE_PATTERN.test(cleanTitle) ||
      CODING_TASK_PATTERNS.some((pat) => pat.test(cleanTitle) || pat.test(rawUrl)) ||
      /\b(code|coding|typescript|javascript|python|react|api|bug|function|component|endpoint|sql|database|query|css|html|refactor|error|debug)\b/i.test(cleanTitle);

    const isResearchContext =
      RESEARCH_PATTERNS.some((pat) => pat.test(cleanTitle) || pat.test(rawUrl)) ||
      /\b(paper|research|study|science|physics|math|history|literature|explain|how\s+does|analysis|breakdown|mechanism)\b/i.test(cleanTitle);

    const isWorkContext =
      WORK_TASK_PATTERNS.some((pat) => pat.test(cleanTitle) || pat.test(rawUrl)) ||
      /\b(draft|proposal|email|meeting|memo|review|spec|requirements|roadmap|client|strategy|presentation)\b/i.test(cleanTitle);

    const isGenericClaude =
      titleLower === 'claude' ||
      titleLower === 'new chat - claude' ||
      titleLower === 'claude - anthropic' ||
      titleLower === 'claude.ai' ||
      titleLower === 'chat - claude';

    if (isCodingContext) {
      return {
        category: 'Coding',
        intent: 'DEEP_WORK',
        confidence: 0.90,
        reason: 'Software engineering, debugging, or code generation in Claude',
        task: `Claude (Coding): ${cleanTitle.replace(/- Claude$/i, '').trim()}`,
        engagementState,
      };
    }

    if (isResearchContext) {
      return {
        category: 'Research',
        intent: 'LEARNING',
        confidence: 0.88,
        reason: 'Analytical research, literature exploration, or topic inquiry in Claude',
        task: `Claude (Research): ${cleanTitle.replace(/- Claude$/i, '').trim()}`,
        engagementState,
      };
    }

    if (isWorkContext) {
      return {
        category: 'Work',
        intent: 'DEEP_WORK',
        confidence: 0.88,
        reason: 'Professional document drafting or workflow execution in Claude',
        task: `Claude (Work): ${cleanTitle.replace(/- Claude$/i, '').trim()}`,
        engagementState,
      };
    }

    if (isGenericClaude) {
      return {
        category: 'Unclassified',
        intent: 'UNKNOWN',
        confidence: 0.40,
        reason: 'Claude conversational workspace with insufficient topic signals to classify task',
        task: 'Claude: New Session',
        engagementState,
      };
    }

    // Default with title evidence
    return {
      category: 'Work',
      intent: 'DEEP_WORK',
      confidence: 0.75,
      reason: 'AI-assisted task execution in Claude',
      task: `Claude: ${cleanTitle.replace(/- Claude$/i, '').trim()}`,
      engagementState,
    };
  }

  // 8. Google AI Studio (aistudio.google.com, console.cloud.google.com, or title containing AI Studio):
  // Must NOT automatically become Deep Work! Inspect model/prompt/task.
  const isGoogleAIStudio =
    domainLower.includes('aistudio.google.com') ||
    titleLower.includes('google ai studio') ||
    titleLower.includes('ai studio') ||
    (domainLower.includes('cloud.google.com') && titleLower.includes('ai studio'));

  if (isGoogleAIStudio) {
    const isCodingContext =
      CODE_FILE_PATTERN.test(cleanTitle) ||
      CODING_TASK_PATTERNS.some((pat) => pat.test(cleanTitle) || pat.test(rawUrl)) ||
      /\b(api|prompt|system\s+instruction|sdk|python|javascript|typescript|json|endpoint|tuning|gemini|function\s+call)\b/i.test(cleanTitle || rawUrl);

    const isResearchContext =
      /\b(eval|evaluation|benchmark|experiment|temperature|tokens|multimodal|comparison|model\s+card)\b/i.test(cleanTitle || rawUrl);

    const isGenericAIStudio =
      titleLower === 'google ai studio' ||
      titleLower === 'ai studio' ||
      titleLower === 'google ai studio - build' ||
      titleLower.trim() === '';

    if (isCodingContext) {
      return {
        category: 'Coding',
        intent: 'DEEP_WORK',
        confidence: 0.92,
        reason: 'AI model prototyping, system prompt engineering, and API integration in Google AI Studio',
        task: `AI Studio (Coding): ${cleanTitle.replace(/- Google AI Studio$/i, '').trim() || 'Prompt Prototyping'}`,
        engagementState,
      };
    }

    if (isResearchContext) {
      return {
        category: 'Research',
        intent: 'LEARNING',
        confidence: 0.90,
        reason: 'Model benchmarking, prompt experimentation, or AI evaluation in Google AI Studio',
        task: `AI Studio (Research): ${cleanTitle.replace(/- Google AI Studio$/i, '').trim()}`,
        engagementState,
      };
    }

    if (isGenericAIStudio) {
      return {
        category: 'Unclassified',
        intent: 'UNKNOWN',
        confidence: 0.40,
        reason: 'Google AI Studio workspace with insufficient prompt or task context',
        task: 'Google AI Studio: Overview',
        engagementState,
      };
    }

    return {
      category: 'Coding',
      intent: 'DEEP_WORK',
      confidence: 0.85,
      reason: 'AI application prototyping in Google AI Studio',
      task: `AI Studio: ${cleanTitle}`,
      engagementState,
    };
  }

  // 9. GitHub & Code Repositories (github.com, gitlab.com):
  // Classify as Coding/Work when evidence supports it; Unclassified when empty feed.
  const isGitHubDomain =
    domainLower === 'github.com' ||
    domainLower.endsWith('.github.com') ||
    domainLower === 'gitlab.com' ||
    domainLower.endsWith('.gitlab.com');

  if (isGitHubDomain) {
    const isRepoOrCode =
      /\/[^/]+\/[^/]+/.test(rawUrl) ||
      titleLower.includes('pull request') ||
      titleLower.includes('issue') ||
      titleLower.includes('commit') ||
      titleLower.includes('repository') ||
      CODE_FILE_PATTERN.test(cleanTitle) ||
      cleanTitle.includes(' · GitHub') ||
      cleanTitle.includes(' · GitLab');

    const isGenericGitHub =
      rawUrl === 'https://github.com' ||
      rawUrl === 'https://github.com/' ||
      rawUrl === 'https://github.com/dashboard' ||
      titleLower === 'github' ||
      titleLower === 'gitlab';

    if (isRepoOrCode && !isGenericGitHub) {
      return {
        category: 'Coding',
        intent: 'DEEP_WORK',
        confidence: 0.94,
        reason: `Software development repository, code review, or pull request on ${domain}`,
        task: `${cleanTitle.replace(/· GitHub$/i, '').trim()} (GitHub)`,
        engagementState,
      };
    }

    if (isGenericGitHub) {
      return {
        category: 'Unclassified',
        intent: 'UNKNOWN',
        confidence: 0.40,
        reason: 'GitHub dashboard feed without active repository or code context',
        task: 'GitHub: Dashboard Feed',
        engagementState,
      };
    }

    return {
      category: 'Coding',
      intent: 'DEEP_WORK',
      confidence: 0.85,
      reason: `Software development workspace on ${domain}`,
      task: `${cleanTitle} (${domain})`,
      engagementState,
    };
  }

  // 10. Technical Documentation & Online Learning:
  // Must NOT automatically become Deep Work! Differentiate Study vs Research vs Coding.
  const isStudyDomain = STUDY_DOMAINS.some((d) => domainLower === d || domainLower.endsWith(`.${d}`));
  const isResearchDomain = RESEARCH_DOMAINS.some((d) => domainLower === d || domainLower.endsWith(`.${d}`));

  if (isStudyDomain) {
    return {
      category: 'Study',
      intent: 'LEARNING',
      confidence: 0.94,
      reason: `Structured academic course, tutorial, or learning challenge on ${domain}`,
      task: `Study: ${cleanTitle}`,
      engagementState,
    };
  }

  if (isResearchDomain) {
    const isCodingDoc =
      domainLower.includes('react.dev') ||
      domainLower.includes('python.org') ||
      domainLower.includes('typescriptlang.org') ||
      domainLower.includes('developer.mozilla.org') ||
      domainLower.includes('stackoverflow.com');

    return {
      category: 'Research',
      intent: 'LEARNING',
      confidence: 0.92,
      reason: `Technical documentation, reference lookup, or academic research on ${domain}`,
      task: `Research: ${cleanTitle}`,
      engagementState,
    };
  }

  // 11. Search Engines (Google Search, Bing, Perplexity, DuckDuckGo) -> Research
  const isSearchEngine =
    domainLower === 'google.com' ||
    domainLower === 'bing.com' ||
    domainLower === 'duckduckgo.com' ||
    domainLower === 'kagi.com' ||
    domainLower === 'perplexity.ai' ||
    domainLower === 'search.brave.com' ||
    domainLower.startsWith('search.') ||
    domainLower.startsWith('www.google.');

  if (isSearchEngine) {
    const cleanSearchTitle = cleanTitle
      .replace(/- Google Search|- Bing|- DuckDuckGo|- Perplexity$/i, '')
      .trim();

    return {
      category: 'Research',
      intent: 'LEARNING',
      confidence: 0.88,
      reason: `Web query and topic research via ${domain}`,
      task: `Search: ${cleanSearchTitle || cleanTitle}`,
      engagementState,
    };
  }

  // 12. Communication Domains (Slack, Discord, Gmail, Outlook, Zoom, WhatsApp, etc.)
  const isCommDomain = COMMUNICATION_DOMAINS.some((d) => domainLower === d || domainLower.endsWith(`.${d}`));
  const isCommApp =
    appLower.includes('slack') ||
    appLower.includes('whatsapp') ||
    appLower.includes('teams') ||
    appLower.includes('discord') ||
    appLower.includes('telegram') ||
    appLower.includes('zoom') ||
    titleLower.includes('gmail') ||
    titleLower.includes('outlook') ||
    titleLower.includes('google meet');

  if (isCommDomain || isCommApp) {
    return {
      category: 'Communication',
      intent: 'COMMUNICATION',
      confidence: 0.92,
      reason: `Team communication, messaging, or meeting in ${domain || cleanApp}`,
      task: `Communication: ${cleanTitle}`,
      engagementState,
    };
  }

  // 13. Dedicated Entertainment & Streaming (Netflix, Disney+, Spotify, Steam, Hulu, etc.)
  const isPureEntertainmentDomain = ENTERTAINMENT_DOMAINS.some((d) => domainLower === d || domainLower.endsWith(`.${d}`));
  const isPureEntertainmentApp =
    appLower.includes('spotify') ||
    appLower.includes('steam') ||
    titleLower.includes('netflix.com') ||
    titleLower.includes('disneyplus.com') ||
    titleLower.includes('twitch.tv');

  if (isPureEntertainmentDomain || isPureEntertainmentApp) {
    return {
      category: 'Entertainment',
      intent: 'DISTRACTION',
      confidence: 0.94,
      reason: `Dedicated entertainment, music streaming, or gaming in ${domain || cleanApp}`,
      task: `Entertainment: ${cleanTitle}`,
      engagementState,
    };
  }

  // 14. YouTube & Video Streaming:
  // Must NOT automatically become Entertainment! Differentiate Study, Entertainment, and Unclassified.
  const isYouTube =
    domainLower.includes('youtube.com') ||
    domainLower.includes('youtu.be') ||
    titleLower.includes('youtube') ||
    appLower.includes('youtube');

  if (isYouTube) {
    const isEducational = EDUCATIONAL_PATTERNS.some((pat) => pat.test(cleanTitle) || pat.test(rawUrl));
    const isEntertainment = ENTERTAINMENT_PATTERNS.some((pat) => pat.test(cleanTitle) || pat.test(rawUrl));

    if (isEducational && !isEntertainment) {
      return {
        category: 'Study',
        intent: 'LEARNING',
        confidence: 0.90,
        reason: 'Technical tutorial or academic lecture identified from YouTube video title',
        task: `YouTube (Study): ${cleanTitle.replace(/- YouTube$/i, '').trim()}`,
        engagementState,
      };
    }

    if (isEntertainment) {
      return {
        category: 'Entertainment',
        intent: 'DISTRACTION',
        confidence: 0.92,
        reason: 'Music, movie trailer, gameplay, or leisure media on YouTube',
        task: `YouTube (Entertainment): ${cleanTitle.replace(/- YouTube$/i, '').trim()}`,
        engagementState,
      };
    }

    // Generic YouTube home, search, or ambiguous title without clear markers -> Unclassified
    return {
      category: 'Unclassified',
      intent: 'UNKNOWN',
      confidence: 0.40,
      reason: 'YouTube video or browsing with insufficient signals to confirm educational or entertainment intent',
      task: `YouTube: ${cleanTitle.replace(/- YouTube$/i, '').trim() || 'Browsing'}`,
      engagementState,
    };
  }

  // 15. Social Media Platforms (Instagram, Reddit, X/Twitter, Threads, LinkedIn):
  // Never classify an entire social platform by name alone! Differentiate Study, Work, Research, Communication, Entertainment, and Unclassified.
  const isSocialPlatform =
    SOCIAL_PLATFORM_DOMAINS.some((d) => domainLower === d || domainLower.endsWith(`.${d}`)) ||
    titleLower.includes('reddit') ||
    titleLower.includes('instagram') ||
    titleLower.includes('twitter') ||
    titleLower.includes('threads') ||
    /\b(x\.com)\b/i.test(titleLower);

  if (isSocialPlatform) {
    const isEdu =
      EDUCATIONAL_PATTERNS.some((pat) => pat.test(cleanTitle) || pat.test(rawUrl)) ||
      /\/r\/(learnprogramming|AskScience|science|history|math|physics|philosophy|biology|compsci)\b/i.test(rawUrl || cleanTitle) ||
      /\b(huberman|tutorial|course|lecture|workshop|deep\s*dive|lesson|study\s*guide|explained)\b/i.test(cleanTitle || rawUrl);

    const isResearch =
      RESEARCH_PATTERNS.some((pat) => pat.test(cleanTitle) || pat.test(rawUrl)) ||
      /\/r\/(MachineLearning|datascience|neuroscience|artificial|academia)\b/i.test(rawUrl || cleanTitle);

    const isCoding =
      CODE_FILE_PATTERN.test(cleanTitle) ||
      CODING_TASK_PATTERNS.some((pat) => pat.test(cleanTitle) || pat.test(rawUrl)) ||
      /\/r\/(programming|typescript|javascript|reactjs|python|golang|rust|webdev|cscareerquestions|algorithms|sysadmin|ExperiencedDevs|devops)\b/i.test(rawUrl || cleanTitle) ||
      /\b(pull\s*request|github\.com|software\s*architecture|microservices|docker|kubernetes|compiler)\b/i.test(cleanTitle || rawUrl);

    const isWork =
      WORK_TASK_PATTERNS.some((pat) => pat.test(cleanTitle) || pat.test(rawUrl)) ||
      domainLower.includes('linkedin.com') ||
      /\b(career|hiring|job\s+posting|recruiter|freelance|contractor|client\s+work)\b/i.test(cleanTitle);

    const isComm =
      /\b(direct|messages|inbox|chat|dms|inmail)\b/i.test(cleanTitle || rawUrl) ||
      rawUrl.includes('/direct/') ||
      rawUrl.includes('/messages');

    const isEnt =
      ENTERTAINMENT_PATTERNS.some((pat) => pat.test(cleanTitle) || pat.test(rawUrl)) ||
      /\/r\/(memes|funny|gaming|gifs|aww|jokes|videos)\b/i.test(rawUrl || cleanTitle) ||
      /\b(meme|memes|funny|comedy|prank|reels|shorts|vlog|gaming|gameplay|stream|clip|trailer)\b/i.test(cleanTitle || rawUrl);

    if (isEdu && !isEnt) {
      return {
        category: 'Study',
        intent: 'LEARNING',
        confidence: 0.90,
        reason: `Educational tutorial, science research, or academic study on ${domain || cleanApp}`,
        task: `${cleanTitle} (${domain || cleanApp})`,
        engagementState,
      };
    }

    if (isResearch && !isEnt) {
      return {
        category: 'Research',
        intent: 'LEARNING',
        confidence: 0.88,
        reason: `Machine learning, scientific publication, or literature inquiry on ${domain || cleanApp}`,
        task: `${cleanTitle} (${domain || cleanApp})`,
        engagementState,
      };
    }

    if (isCoding && !isEnt) {
      return {
        category: 'Coding',
        intent: 'DEEP_WORK',
        confidence: 0.88,
        reason: `Software engineering, systems architecture, or developer discussion on ${domain || cleanApp}`,
        task: `${cleanTitle} (${domain || cleanApp})`,
        engagementState,
      };
    }

    if (isComm) {
      return {
        category: 'Communication',
        intent: 'COMMUNICATION',
        confidence: 0.90,
        reason: `Direct messaging or private communication on ${domain || cleanApp}`,
        task: `Direct message (${domain || cleanApp})`,
        engagementState,
      };
    }

    if (isWork && !isEnt) {
      return {
        category: 'Work',
        intent: 'DEEP_WORK',
        confidence: 0.85,
        reason: `Professional networking or workplace industry context on ${domain || cleanApp}`,
        task: `${cleanTitle} (${domain || cleanApp})`,
        engagementState,
      };
    }

    if (isEnt) {
      return {
        category: 'Entertainment',
        intent: 'DISTRACTION',
        confidence: 0.90,
        reason: `Recreational media, funny memes, or leisure entertainment on ${domain || cleanApp}`,
        task: `Entertainment: ${cleanTitle}`,
        engagementState,
      };
    }

    // When evidence is insufficient: never assume entertainment! Classify as Unclassified
    return {
      category: 'Unclassified',
      intent: 'UNKNOWN',
      confidence: 0.40,
      reason: `Insufficient contextual evidence on ${domain || cleanApp} to confirm study, work, or entertainment intent`,
      task: `${cleanTitle} (${domain || cleanApp})`,
      engagementState,
    };
  }

  // 16. Code Editors & IDEs (VS Code, JetBrains, PyCharm, Xcode, Sublime, Vim, Neovim, Cursor)
  const isIde =
    appLower.includes('code') ||
    appLower.includes('studio') ||
    appLower.includes('intellij') ||
    appLower.includes('pycharm') ||
    appLower.includes('webstorm') ||
    appLower.includes('xcode') ||
    appLower.includes('sublime') ||
    appLower.includes('vim') ||
    appLower.includes('neovim') ||
    appLower.includes('cursor');

  if (isIde) {
    const hasCodeFile = CODE_FILE_PATTERN.test(cleanTitle);
    const isGenericEditor =
      cleanTitle.toLowerCase() === 'visual studio code' ||
      cleanTitle.toLowerCase() === 'code' ||
      cleanTitle.toLowerCase() === 'untitled' ||
      cleanTitle.toLowerCase() === 'cursor';

    if (hasCodeFile || cleanTitle.includes(' - ')) {
      return {
        category: 'Coding',
        intent: 'DEEP_WORK',
        confidence: 0.95,
        reason: 'Active code editor with open project buffer or source file',
        task: `Editing ${cleanTitle.split(' - ')[0] || cleanTitle}`,
        engagementState,
      };
    }

    if (isGenericEditor) {
      return {
        category: 'Unclassified',
        intent: 'UNKNOWN',
        confidence: 0.45,
        reason: 'Editor open without active document or workspace context',
        task: `${cleanApp}: Empty workspace`,
        engagementState,
      };
    }

    return {
      category: 'Coding',
      intent: 'DEEP_WORK',
      confidence: 0.85,
      reason: 'Software development environment active',
      task: `${cleanApp}: ${cleanTitle}`,
      engagementState,
    };
  }

  // 17. Developer Terminal / CLI:
  // If running build, git, npm, python, cargo commands -> Coding
  if (isTerminalApp) {
    const isDevCommand =
      /\b(npm|yarn|pnpm|cargo|pip|python|node|git|gcc|clang|rustc|docker|make|tsc|deno|bun)\b/i.test(cleanTitle);

    if (isDevCommand) {
      return {
        category: 'Coding',
        intent: 'DEEP_WORK',
        confidence: 0.90,
        reason: 'Development command line execution and build processes',
        task: `Terminal: ${cleanTitle}`,
        engagementState,
      };
    }

    return {
      category: 'Utilities',
      intent: 'ADMIN',
      confidence: 0.75,
      reason: 'System terminal shell',
      task: `${cleanApp}: ${cleanTitle}`,
      engagementState,
    };
  }

  // 18. Operating System Utilities & Administrative Tools
  const isSystemUtility =
    UTILITY_DOMAINS.some((d) => domainLower === d || domainLower.endsWith(`.${d}`)) ||
    appLower.includes('calculator') ||
    appLower.includes('calc') ||
    appLower.includes('explorer') ||
    appLower.includes('task manager') ||
    appLower.includes('settings') ||
    appLower.includes('finder') ||
    appLower.includes('1password') ||
    appLower.includes('bitwarden');

  if (isSystemUtility) {
    return {
      category: 'Utilities',
      intent: 'ADMIN',
      confidence: 0.85,
      reason: `Operating system utility or everyday management tool in ${domain || cleanApp}`,
      task: `Utility: ${cleanTitle}`,
      engagementState,
    };
  }

  // 19. Generic browser new tabs / empty windows -> Unclassified
  const isGenericTab =
    titleLower === 'new tab' ||
    titleLower === 'google' ||
    titleLower === 'chrome' ||
    titleLower === 'edge' ||
    titleLower === 'start page' ||
    titleLower.trim() === '';

  if (isGenericTab) {
    return {
      category: 'Unclassified',
      intent: 'UNKNOWN',
      confidence: 0.30,
      reason: 'Generic browser navigation without specific task content',
      task: `${cleanApp}: New Tab`,
      engagementState: 'passive',
    };
  }

  // 20. Default fallback: Unclassified instead of guessing
  return {
    category: 'Unclassified',
    intent: 'UNKNOWN',
    confidence: 0.35,
    reason: 'Insufficient contextual signals to classify activity',
    task: `${cleanApp}: ${cleanTitle}`,
    engagementState,
  };
}
