import express from 'express';
import bcrypt from 'bcryptjs';
import path from 'path';
import fs from 'fs';
import { ZipArchive } from 'archiver';
import { ai, AGENT_FILE } from '../config/env.js';
import type { ChunkSummary, DailySynthesis, TelemetryEvent, DeviceState } from '../../../shared/types/chronotrace.js';
import type { UserRecord, AuthSession, DeviceRecord } from '../types/models.js';
import { getUsers, saveUsers, getAuthSessions, saveAuthSessions } from '../services/userStore.js';
import { getUserDir, defaultDeviceRecord, HEARTBEAT_TIMEOUT_MS, isAgentLive, getUserDeviceRecord, saveUserDeviceRecord, getUserTelemetry, saveUserTelemetry, getUserSessions, saveUserSessions, getUserSummary, saveUserSummary, getUserEventIndex, saveUserEventIndex, getUserPreferences } from '../services/dataStore.js';
import { getSessionToken, getAuthenticatedUser, createSessionForUser, toUserProfile, toDeviceStatus } from '../services/authHelpers.js';
import { classifyActivity, normalizeCategory } from '../../../shared/classification/classifier.js';

const router = express.Router();

// -------------------------------------------------------------
// WINDOWS AGENT COLLECTION SCRIPT & POWERSHELL COMMAND
// -------------------------------------------------------------

// The agent identifies itself with its own device token (body, X-User-Token header
// or Bearer). Nothing else is accepted, and there is no default-user fallback.
// The agent identifies itself with its own device token (header, bearer, body, or query).
function resolveTargetUserForAgent(req: express.Request): UserRecord | null {
  const auth = req.headers['authorization'];
  const bearer = typeof auth === 'string' && auth.startsWith('Bearer ') ? auth.substring(7).trim() : null;
  const headerTok = req.headers['x-device-token'] || req.headers['x-user-token'];
  const candidate =
    req.body?.deviceToken ||
    req.body?.userToken ||
    (typeof headerTok === 'string' ? headerTok : null) ||
    (typeof req.query?.token === 'string' ? req.query.token : null) ||
    bearer;
  if (!candidate || typeof candidate !== 'string') return null;
  return getUsers().find((u) => u.deviceToken === candidate) || null;
}

const sendAgentScript = (req: express.Request, res: express.Response) => {
  try {
    const agentFilePath = AGENT_FILE;
    let code = fs.readFileSync(agentFilePath, 'utf-8');

    let proto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'https';
    const host = (req.headers['x-forwarded-host'] as string) || req.get('host') || 'localhost:3000';
    if (host.includes('.run.app') || host.includes('aistudio')) {
      proto = 'https';
    }
    const computedOrigin = `${proto}://${host}`;
    const hostUrl = process.env.APP_URL ? process.env.APP_URL.replace(/\/+$/, '') : computedOrigin;

    let user = res.locals.user as UserRecord | undefined;
    if (!user && req.query.token) {
      const qToken = String(req.query.token).trim();
      user = getUsers().find((u) => u.deviceToken === qToken);
    }
    if (!user) {
      user = getAuthenticatedUser(req);
    }
    const deviceToken = user ? user.deviceToken : (typeof req.query.token === 'string' ? String(req.query.token).trim() : '');

    code = code.replace(
      /DEFAULT_SERVER\s*=\s*["'][^"']+["']/,
      `DEFAULT_SERVER = "${hostUrl}"`
    );

    code = code.replace(
      /DEFAULT_USER_TOKEN\s*=\s*["'][^"']*["']/,
      `DEFAULT_USER_TOKEN = "${deviceToken}"`
    );

    res.setHeader('Content-Type', 'text/x-python; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="chronotrace_agent.py"');
    res.send(code);
  } catch (e: any) {
    console.error('Error serving agent script:', e);
    res.status(500).send('# Error serving agent script: ' + (e?.message || 'unknown error'));
  }
};

router.get([
  '/api/download-agent',
  '/api/download/chronotrace_agent.py',
  '/download/chronotrace_agent.py',
  '/agent.py',
  '/chronotrace_agent.py',
  '/api/agent.py',
  '/api/chronotrace_agent.py',
  '/public/agent.py',
  '/public/chronotrace_agent.py',
], sendAgentScript);

// Download Chrome Extension package
router.get(['/api/download-extension', '/api/download/extension.zip', '/download/extension.zip'], (req, res) => {
  try {
    const extensionDir = path.resolve(process.cwd(), 'extension');
    if (!fs.existsSync(extensionDir)) {
      return res.status(404).json({ error: 'Extension directory not found' });
    }

    let proto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'https';
    const host = (req.headers['x-forwarded-host'] as string) || req.get('host') || 'localhost:3000';
    if (host.includes('.run.app') || host.includes('aistudio')) {
      proto = 'https';
    }
    const hostUrl = `${proto}://${host}`;

    const user = resolveTargetUserForAgent(req) || getAuthenticatedUser(req);
    const deviceToken = user?.deviceToken || (typeof req.query.token === 'string' ? req.query.token : '') || '';

    const archive = new ZipArchive({ zlib: { level: 9 } });
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="chronotrace-browser-extension.zip"');

    archive.on('error', (err) => {
      console.error('Error packaging extension:', err);
      if (!res.headersSent) {
        res.status(500).json({ error: 'Failed to package extension' });
      }
    });

    archive.pipe(res);

    // Read files in extension directory and inject config into background.js
    const files = fs.readdirSync(extensionDir);
    for (const f of files) {
      const fullPath = path.join(extensionDir, f);
      if (fs.statSync(fullPath).isDirectory()) continue;

      if (f === 'background.js') {
        let bgCode = fs.readFileSync(fullPath, 'utf8');
        bgCode = bgCode.replace(
          /const DEFAULT_SERVER = ['"][^'"]*['"]/,
          `const DEFAULT_SERVER = '${hostUrl}'`
        );
        if (deviceToken) {
          bgCode = bgCode.replace(
            /deviceToken:\s*['"][^'"]*['"]/,
            `deviceToken: '${deviceToken}'`
          );
        }
        archive.append(bgCode, { name: 'background.js' });
      } else {
        archive.file(fullPath, { name: f });
      }
    }

    archive.finalize();
  } catch (e: any) {
    console.error('Error serving extension zip:', e);
    if (!res.headersSent) {
      res.status(500).json({ error: e?.message || 'Error generating extension zip' });
    }
  }
});

router.get('/api/agent/powershell', (req, res) => {
  let proto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'https';
  const host = (req.headers['x-forwarded-host'] as string) || req.get('host') || 'localhost:3000';
  if (host.includes('.run.app') || host.includes('aistudio')) {
    proto = 'https';
  }
  const appOrigin = process.env.APP_URL ? process.env.APP_URL.replace(/\/+$/, '') : `${proto}://${host}`;
  const user = res.locals.user as UserRecord;

  const script = `cd "$env:USERPROFILE\\Downloads"; python chronotrace_agent.py`;
  res.json({ script, origin: appOrigin, deviceToken: user.deviceToken });
});

// -------------------------------------------------------------
// LIVE INGESTION FROM WINDOWS AGENT
// -------------------------------------------------------------

function ingestSingleEvent(
  user: UserRecord,
  payload: any,
  deviceRec: DeviceRecord,
  telemetry: TelemetryEvent[],
  sessions: ChunkSummary[],
  summary: DailySynthesis,
  eventIndex: Set<string>
): { ingested: boolean; duplicate: boolean } {
  // Reject synthetic or test events from normal user telemetry
  if (
    payload.isTest ||
    payload.test ||
    payload.sourceType === 'synthetic-test' ||
    (typeof payload.id === 'string' && (payload.id.includes('dummy') || payload.id.includes('seed-')))
  ) {
    return { ingested: false, duplicate: true };
  }

  const serverNowIso = new Date().toISOString();
  const nowIso = payload.utcTimestamp || payload.recorded_at || serverNowIso;
  const nowTime =
    payload.localTime ||
    new Date(nowIso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const nowDate = payload.localDate || new Date(nowIso).toISOString().split('T')[0];

  const appName = (payload.appName || 'Active Window').trim();
  const winTitle = (payload.windowTitle || appName).trim();
  const eventId = payload.id || `evt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const eventSig = `${nowDate}:::${nowTime}:::${appName}:::${winTitle}`;

  // Strict persistent idempotency: check against persistent eventIndex and stored telemetry
  if (
    eventIndex.has(eventId) ||
    eventIndex.has(eventSig) ||
    telemetry.some(
      (e) =>
        e.id === eventId ||
        (e.date === nowDate && e.timestamp === nowTime && e.app_name === appName && e.window_title === winTitle)
    )
  ) {
    return { ingested: false, duplicate: true };
  }

  eventIndex.add(eventId);
  eventIndex.add(eventSig);

  const deltaSec = Math.max(1, Number(payload.deltaSeconds || payload.durationSeconds) || 2);

  // Browser-level context
  const url = typeof payload.url === 'string' ? payload.url : typeof payload.browser_url === 'string' ? payload.browser_url : undefined;
  let domain = typeof payload.domain === 'string' ? payload.domain : typeof payload.browser_domain === 'string' ? payload.browser_domain : undefined;
  if (!domain && url) {
    try {
      domain = new URL(url).hostname.replace(/^www\./, '');
    } catch {
      domain = undefined;
    }
  }
  const pageTitle = typeof payload.page_title === 'string' ? payload.page_title : typeof payload.tab_title === 'string' ? payload.tab_title : undefined;
  const tabId = payload.tab_id !== undefined ? Number(payload.tab_id) : undefined;
  const isActiveTab = payload.is_active_tab !== undefined ? Boolean(payload.is_active_tab) : undefined;
  const pageVisible = payload.page_visible !== undefined ? Boolean(payload.page_visible) : undefined;

  // Interaction engagement signals (privacy-safe counters only)
  const scrollCount = Number(payload.scroll_count ?? payload.scrollCount) || 0;
  const clickCount = Number(payload.click_count ?? payload.clickCount) || 0;
  const keyCount = Number(payload.key_count ?? payload.keyCount ?? payload.keyboard_events) || 0;
  const activeDwellMs = payload.active_dwell_ms !== undefined ? Number(payload.active_dwell_ms) : undefined;
  const idleDwellMs = payload.idle_dwell_ms !== undefined ? Number(payload.idle_dwell_ms) : undefined;
  const isIdle = payload.is_idle !== undefined ? Boolean(payload.is_idle) : (idleDwellMs !== undefined && activeDwellMs !== undefined ? idleDwellMs > activeDwellMs * 2 : false);

  // Track revisits across today's telemetry
  const previousVisits = telemetry.filter((t) => (domain && t.domain === domain) || (url && t.url === url));
  const isRevisited = previousVisits.length > 0;
  const revisitCount = previousVisits.length + 1;

  const userPrefs = getUserPreferences(user.id);
  const classification = classifyActivity(appName, winTitle, userPrefs, {
    url,
    domain,
    scrollCount,
    clickCount,
    keyCount,
    activeDwellMs,
    idleDwellMs,
    isIdle,
    isVisible: pageVisible,
    revisited: isRevisited,
    revisitCount,
    durationSeconds: deltaSec,
  });

  let cat = classification.category as string;
  let intent = classification.intent;
  let confidence = classification.confidence;
  let reason = classification.reason;
  let isCollector = classification.isCollectorProcess || false;
  let task = payload.overrideTask || payload.specificTask || classification.task || (domain ? `${domain}: ${winTitle}` : `${appName}: ${winTitle}`);

  // If payload explicitly provided an override category, honor it unless collector
  if (payload.overrideCategory) {
    cat = payload.overrideCategory;
    if (cat === 'Deep Work') intent = 'DEEP_WORK';
    else if (cat === 'Learning' || cat === 'Learning & Research') intent = 'LEARNING';
    else if (cat === 'Entertainment' || cat === 'Distraction') intent = 'DISTRACTION';
    else if (cat === 'Communication') intent = 'COMMUNICATION';
    else if (cat === 'Utility' || cat === 'Utility / Admin' || cat === 'Admin') intent = 'ADMIN';
    else intent = 'UNKNOWN';
  }

  // Collector process is strictly excluded from focus/productivity metrics
  if (isCollector) {
    cat = 'Utilities';
    intent = 'ADMIN';
  }

  const activeMs = activeDwellMs !== undefined ? activeDwellMs : (isIdle ? 0 : deltaSec * 1000);
  const idleMs = idleDwellMs !== undefined ? idleDwellMs : (isIdle ? deltaSec * 1000 : 0);
  const activeSec = Math.round(activeMs / 1000);
  const idleSec = Math.round(idleMs / 1000);
  const engagementState = classification.engagementState || (isIdle ? 'idle' : (clickCount > 0 || scrollCount > 0 || keyCount > 0 ? 'engaged' : 'passive'));

  // Session chunk reconstruction with clean session boundaries
  const lastSession = sessions[sessions.length - 1];
  const isDist = cat === 'Entertainment' || cat === 'Distraction';
  const isFocusCategory =
    cat === 'Coding' ||
    cat === 'Work' ||
    cat === 'Study' ||
    cat === 'Research' ||
    cat === 'Deep Work' ||
    cat === 'Learning' ||
    cat === 'Learning & Research';

  let breakType: 'intentional_break' | 'distraction_rabbit_hole' | 'micro_switch' | null = null;
  let isDistractionDetected = isDist;

  if (isDist) {
    const prevWasProductive = lastSession && (
      lastSession.dominant_category === 'Coding' ||
      lastSession.dominant_category === 'Work' ||
      lastSession.dominant_category === 'Study' ||
      lastSession.dominant_category === 'Research' ||
      lastSession.dominant_category === 'Deep Work' ||
      lastSession.dominant_category === 'Learning' ||
      lastSession.dominant_category === 'Learning & Research'
    );
    // Intentional break: brief entertainment (<= 300s) right after a focused work block
    if (prevWasProductive && deltaSec <= 300) {
      breakType = 'intentional_break';
      intent = 'DISTRACTION_BREAK';
      isDistractionDetected = false;
      reason = 'Intentional mental break / recovery following focused work interval';
    } else {
      breakType = 'distraction_rabbit_hole';
      isDistractionDetected = true;
    }
  }

  const mouseMoveCount = Number(payload.mouse_move_count ?? payload.mouseMoves) || 0;

  const newEvent: TelemetryEvent = {
    id: eventId,
    timestamp: nowTime,
    start_time: payload.localTime || payload.startTime || nowTime,
    end_time: payload.endTime || nowTime,
    duration_s: deltaSec,
    date: nowDate,
    recorded_at: payload.recorded_at || payload.localTimestamp || nowIso,
    dwell_ms: deltaSec * 1000,
    active_dwell_ms: activeMs,
    idle_dwell_ms: idleMs,
    category: cat,
    intent,
    break_type: breakType,
    confidence,
    classification_reason: reason,
    is_collector_process: isCollector,
    app_name: appName,
    window_title: winTitle,
    keyboard_events: keyCount,
    scroll_count: scrollCount,
    click_count: clickCount,
    key_count: keyCount,
    mouse_move_count: mouseMoveCount,
    url,
    domain,
    page_title: pageTitle,
    tab_id: tabId,
    is_active_tab: isActiveTab,
    page_visible: pageVisible,
    engagement_state: engagementState,
    revisited: isRevisited,
    revisit_count: revisitCount,
  };

  telemetry.push(newEvent);
  if (telemetry.length > 1000) telemetry.shift();

  deviceRec.lastEventTime = nowTime;
  deviceRec.lastLocalDate = nowDate;
  deviceRec.currentWindowTitle = winTitle;
  deviceRec.currentForegroundApp = appName;

  // Web service / domain extractor to prevent cross-site session contamination (e.g. YouTube into GitHub)
  const extractContextDomain = (app: string, title: string, dom?: string, u?: string): string => {
    if (dom && dom.trim()) return dom.toLowerCase().trim();
    if (u) {
      try {
        return new URL(u.startsWith('http') ? u : `https://${u}`).hostname.replace(/^www\./, '').toLowerCase();
      } catch {}
    }
    const t = (title || '').toLowerCase();
    if (t.includes('github.com') || t.includes(' · github') || t.includes(' - github')) return 'github.com';
    if (t.includes('gitlab.com') || t.includes(' · gitlab')) return 'gitlab.com';
    if (t.includes('youtube.com') || t.includes('youtu.be') || t.includes(' - youtube')) return 'youtube.com';
    if (t.includes('aistudio.google.com') || t.includes('google ai studio') || t.includes('ai studio')) return 'aistudio.google.com';
    if (t.includes('claude.ai') || t.includes(' - claude') || t.includes('claude')) return 'claude.ai';
    if (t.includes('calendar.google.com') || t.includes('google calendar')) return 'calendar.google.com';
    if (t.includes('instagram.com') || t.includes(' · instagram') || t.includes(' - instagram')) return 'instagram.com';
    if (t.includes('reddit.com') || t.includes(' - reddit')) return 'reddit.com';
    if (t.includes('notion.so') || t.includes('notion')) return 'notion.so';
    if (t.includes('linear.app') || t.includes('linear')) return 'linear.app';
    if (t.includes('slack.com') || t.includes('slack')) return 'slack.com';
    return '';
  };

  const isBrowserApp = (name: string) =>
    ['google chrome', 'chrome', 'microsoft edge', 'edge', 'brave', 'brave browser', 'firefox', 'opera'].includes(name.toLowerCase());

  const lastDomain = extractContextDomain(
    lastSession?.anchor_app || '',
    lastSession?.main_events?.[0]?.title || '',
    lastSession?.domain,
    lastSession?.url
  );
  const currentDomain = extractContextDomain(appName, winTitle, domain, url);

  // Check if this event continues the active anchor session
  // Strict rule: Never merge unrelated activities or different websites (e.g. YouTube into GitHub)
  let isContinuingSameSession = false;
  if (lastSession && (lastSession.closed_by === 'ACTIVE' || !lastSession.closed_by)) {
    const sameApp = lastSession.anchor_app?.toLowerCase() === appName.toLowerCase();
    const sameCategory = normalizeCategory(lastSession.dominant_category || '') === normalizeCategory(cat);

    if (sameApp && sameCategory) {
      if (isBrowserApp(appName)) {
        // In browser: must have identical context domain or identical window title
        if (lastDomain && currentDomain) {
          isContinuingSameSession = lastDomain === currentDomain;
        } else if (!lastDomain && !currentDomain) {
          // If no domain detected, only continue if same base window title
          isContinuingSameSession = lastSession.main_events?.some((m) => m.title === winTitle) || false;
        } else {
          isContinuingSameSession = false;
        }
      } else {
        // Desktop app: same application and same category
        isContinuingSameSession = true;
      }
    }
  }

  if (isContinuingSameSession) {
    lastSession.duration_s += deltaSec;
    lastSession.active_duration_s = (lastSession.active_duration_s || 0) + activeSec;
    lastSession.idle_duration_s = (lastSession.idle_duration_s || 0) + idleSec;
    lastSession.scroll_count = (lastSession.scroll_count || 0) + scrollCount;
    lastSession.click_count = (lastSession.click_count || 0) + clickCount;
    lastSession.key_count = (lastSession.key_count || 0) + keyCount;
    if (url && !lastSession.url) lastSession.url = url;
    if (domain && !lastSession.domain) lastSession.domain = domain;
    lastSession.end_time = payload.endTime || nowTime;

    const sub = lastSession.main_events?.find((m) => m.title === winTitle);
    if (sub) {
      sub.dwell_s += deltaSec;
      sub.keys = (sub.keys || 0) + keyCount;
      sub.clicks = (sub.clicks || 0) + clickCount;
      sub.scrolls = (sub.scrolls || 0) + scrollCount;
      sub.active_dwell_s = (sub.active_dwell_s || 0) + activeSec;
      sub.idle_dwell_s = (sub.idle_dwell_s || 0) + idleSec;
    } else if (lastSession.main_events) {
      lastSession.main_events.push({
        app: appName,
        title: winTitle,
        dwell_s: deltaSec,
        keys: keyCount,
        clicks: clickCount,
        scrolls: scrollCount,
        active_dwell_s: activeSec,
        idle_dwell_s: idleSec,
        url,
        domain,
      });
    }

    const totalInteractions = (lastSession.click_count || 0) * 3 + (lastSession.scroll_count || 0) * 1 + (lastSession.key_count || 0) * 2;
    const effectiveSec = Math.max(5, lastSession.duration_s);
    let sessionEngagement = 0;
    if (isIdle) {
      sessionEngagement = 0;
      lastSession.engagement_state = 'idle';
    } else if (totalInteractions > 0) {
      sessionEngagement = Math.min(100, Math.max(40, Math.round((totalInteractions / (effectiveSec / 10)) * 25) + 35));
      lastSession.engagement_state = 'engaged';
    } else if ((lastSession.active_duration_s || 0) >= 5) {
      // Desktop active foreground window with dwell: grounded engagement
      sessionEngagement = Math.min(95, Math.max(70, 75 + Math.min(20, Math.round((lastSession.active_duration_s || 0) / 60))));
      lastSession.engagement_state = 'active';
    } else {
      sessionEngagement = 20;
      lastSession.engagement_state = 'open_only';
    }
    lastSession.engagement_score = sessionEngagement;

    lastSession.summary = domain
      ? `Active on ${domain}: ${winTitle} (${Math.round(lastSession.duration_s)}s duration, ${Math.round(lastSession.active_duration_s || 0)}s active).`
      : `Active in ${appName}: ${winTitle} (${Math.round(lastSession.duration_s)}s duration, ${Math.round(lastSession.active_duration_s || 0)}s active).`;
  } else {
    // Finalize previous session cleanly if it was active
    if (lastSession && (lastSession.closed_by === 'ACTIVE' || !lastSession.closed_by)) {
      lastSession.closed_by = 'WINDOW_TRANSITION';
    }

    // Check for rapid tab/window thrashing
    const recentSessions = sessions.slice(-3);
    const isRapidFlicker = recentSessions.length >= 2 && recentSessions.every((s) => s.duration_s <= 15);
    if (isRapidFlicker && !breakType) {
      breakType = 'micro_switch';
    }

    const chunkId = `chk_${eventId}`;
    const totalInteractions = clickCount * 3 + scrollCount * 1 + keyCount * 2;
    let initialEngagement = 0;
    if (isIdle) {
      initialEngagement = 0;
    } else if (totalInteractions > 0) {
      initialEngagement = Math.min(100, Math.max(40, Math.round((totalInteractions / Math.max(1, deltaSec / 10)) * 25) + 35));
    } else if (activeSec >= 5) {
      initialEngagement = Math.min(95, Math.max(70, 75 + Math.min(20, Math.round(activeSec / 60))));
    } else {
      initialEngagement = 20;
    }

    const chunkState = classification.engagementState || (isIdle ? 'idle' : (initialEngagement >= 70 ? 'active' : (totalInteractions > 0 ? 'engaged' : 'open_only')));

    const newChunk: ChunkSummary = {
      chunk_id: chunkId,
      recorded_at: payload.recorded_at || payload.localTimestamp || nowIso,
      localDate: nowDate,
      duration_s: deltaSec,
      active_duration_s: activeSec,
      idle_duration_s: idleSec,
      start_time: payload.localTime || payload.startTime || nowTime,
      end_time: payload.endTime || nowTime,
      closed_by: 'ACTIVE',
      main_events: [{
        app: appName,
        title: winTitle,
        dwell_s: deltaSec,
        keys: keyCount,
        clicks: clickCount,
        scrolls: scrollCount,
        active_dwell_s: activeSec,
        idle_dwell_s: idleSec,
        url,
        domain,
      }],
      anchor_app: appName,
      anchor_held_s: deltaSec,
      returned_to_anchor: true,
      url,
      domain,
      scroll_count: scrollCount,
      click_count: clickCount,
      key_count: keyCount,
      engagement_score: initialEngagement,
      engagement_state: chunkState,
      keyboard: { total_keys: keyCount, rate_per_min: Math.round((keyCount / Math.max(1, deltaSec)) * 60) },
      micro_behavior: {
        total_rapid_switches: isRapidFlicker ? 3 : 1,
        tab_flickers: isRapidFlicker ? 2 : 0,
        avg_micro_dwell_ms: deltaSec * 1000,
        dominant_pattern: isRapidFlicker ? 'RAPID_SWITCHING' : 'NORMAL',
        unique_micro_apps: [appName],
      },
      categories_present: [cat],
      dominant_category: cat,
      copy_paste_events: 0,
      session_start_restless: false,
      intent,
      confidence,
      classification_reason: reason,
      is_collector_process: isCollector,
      primary_task: task,
      distraction_detected: isDistractionDetected,
      distraction_type: breakType === 'intentional_break' ? 'intentional_break' : isDistractionDetected ? 'rabbit_hole' : null,
      break_type: breakType,
      work_state: isFocusCategory ? 'productive' : isDistractionDetected ? 'unsettled' : 'settled',
      unresolved_threads: [],
      summary: domain
        ? `Active session on ${domain} (${appName}): ${winTitle} (${deltaSec}s dwell, ${activeSec}s active).`
        : `Active session in ${appName}: ${winTitle} (${deltaSec}s dwell, ${activeSec}s active).`,
      revisited: isRevisited,
      revisit_count: revisitCount,
    };
    sessions.push(newChunk);
    if (sessions.length > 200) sessions.shift();
  }

  // Update Daily Synthesis
  summary.date = nowDate;
  summary.total_telemetry_s = (summary.total_telemetry_s || 0) + deltaSec;
  summary.total_active_dwell_s = (summary.total_active_dwell_s || 0) + activeSec;
  summary.total_idle_dwell_s = (summary.total_idle_dwell_s || 0) + idleSec;

  // Exclude ChronoTrace collector from productivity metrics
  if (!isCollector) {
    if (isFocusCategory) {
      // Dwell duration only counts towards pure deep work if user was actively engaged or not flagged as idle
      const productiveActiveSec = isIdle ? 0 : activeSec;
      summary.total_deep_work_s = (summary.total_deep_work_s || 0) + productiveActiveSec;
    }

    if (cat === 'Coding') summary.total_coding_s = (summary.total_coding_s || 0) + activeSec;
    else if (cat === 'Work') summary.total_work_s = (summary.total_work_s || 0) + activeSec;
    else if (cat === 'Study') {
      summary.total_study_s = (summary.total_study_s || 0) + activeSec;
      summary.total_learning_s = (summary.total_learning_s || 0) + activeSec;
    } else if (cat === 'Research') {
      summary.total_research_s = (summary.total_research_s || 0) + activeSec;
      summary.total_learning_s = (summary.total_learning_s || 0) + activeSec;
    } else if (cat === 'Entertainment' || cat === 'Distraction') {
      if (breakType !== 'intentional_break') {
        summary.total_distraction_s = (summary.total_distraction_s || 0) + deltaSec;
        summary.total_entertainment_s = (summary.total_entertainment_s || 0) + deltaSec;
        if (winTitle && !winTitle.toLowerCase().includes('chronotrace')) {
          if (!summary.distraction_triggers) summary.distraction_triggers = [];
          if (!summary.distraction_triggers.includes(winTitle.slice(0, 45))) {
            summary.distraction_triggers.push(winTitle.slice(0, 45));
          }
        }
      }
    } else if (cat === 'Communication') {
      summary.total_comm_s = (summary.total_comm_s || 0) + deltaSec;
      summary.total_communication_s = (summary.total_communication_s || 0) + deltaSec;
    } else if (cat === 'Productivity & Planning') {
      summary.total_productivity_planning_s = (summary.total_productivity_planning_s || 0) + deltaSec;
      summary.total_utility_s = (summary.total_utility_s || 0) + deltaSec;
    } else if (cat === 'Utilities' || cat === 'Utility' || cat === 'Utility / Admin' || cat === 'Admin') {
      summary.total_utilities_s = (summary.total_utilities_s || 0) + deltaSec;
      summary.total_utility_s = (summary.total_utility_s || 0) + deltaSec;
    } else if (cat === 'Idle') {
      summary.total_idle_s = (summary.total_idle_s || 0) + deltaSec;
    } else {
      summary.total_unclassified_s = (summary.total_unclassified_s || 0) + deltaSec;
    }
  } else {
    summary.total_utilities_s = (summary.total_utilities_s || 0) + deltaSec;
    summary.total_utility_s = (summary.total_utility_s || 0) + deltaSec;
  }

  return { ingested: true, duplicate: false };
}

router.post('/api/ingest-event', (req, res) => {
  try {
    const user = resolveTargetUserForAgent(req);
    if (!user) {
      return res.status(401).json({ error: 'Unrecognized device token. Device not bound to any user account.' });
    }

    const deviceRec = getUserDeviceRecord(user.id);
    if (deviceRec.paused) {
      return res.status(409).json({
        status: 'paused',
        received: false,
        message: 'Activity collection is currently paused on the website.',
      });
    }

    const payload = req.body || {};

    // Reject synthetic or test events from normal user telemetry
    if (payload.isTest || payload.test || payload.sourceType === 'synthetic-test') {
      return res.status(400).json({ error: 'Synthetic/test events are disabled in production telemetry.' });
    }

    // Always use server-authoritative time for heartbeat timestamps to prevent client clock skew
    const serverNowIso = new Date().toISOString();

    // Mark heartbeat
    if (!isAgentLive(deviceRec)) {
      deviceRec.connectedSince = serverNowIso;
    }
    deviceRec.lastHeartbeatAt = serverNowIso;
    deviceRec.lastSuccessfulConnectionAt = serverNowIso;

    if (payload.deviceName) deviceRec.deviceName = payload.deviceName;
    if (payload.os) deviceRec.os = payload.os;
    if (payload.agentVersion) deviceRec.agentVersion = payload.agentVersion;
    if (payload.timezoneOffsetMinutes !== undefined) deviceRec.timezoneOffsetMinutes = payload.timezoneOffsetMinutes;
    if (payload.timezoneName) deviceRec.timezoneName = payload.timezoneName;

    // Heartbeat-only signal (with optional current active window metadata)
    if (payload.heartbeat && !payload.appName && !payload.events) {
      if (payload.current) {
        if (payload.current.windowTitle) deviceRec.currentWindowTitle = payload.current.windowTitle;
        if (payload.current.appName) deviceRec.currentForegroundApp = payload.current.appName;
      }
      saveUserDeviceRecord(user.id, deviceRec);
      return res.json({ status: 'ok', received: true, heartbeat: true, user: user.username });
    }

    const telemetry = getUserTelemetry(user.id);
    const sessions = getUserSessions(user.id);
    const summary = getUserSummary(user.id);
    const eventIndex = getUserEventIndex(user.id);

    let ingestedCount = 0;
    let duplicateCount = 0;

    // Check if batch of events was provided (e.g. from local offline queue)
    if (Array.isArray(payload.events) && payload.events.length > 0) {
      for (const ev of payload.events) {
        if (!ev.appName && !ev.windowTitle) continue;
        const resIngest = ingestSingleEvent(user, ev, deviceRec, telemetry, sessions, summary, eventIndex);
        if (resIngest.ingested) ingestedCount++;
        if (resIngest.duplicate) duplicateCount++;
      }
    } else if (payload.appName) {
      const resIngest = ingestSingleEvent(user, payload, deviceRec, telemetry, sessions, summary, eventIndex);
      if (resIngest.ingested) ingestedCount++;
      if (resIngest.duplicate) duplicateCount++;
    }

    saveUserEventIndex(user.id, eventIndex);
    saveUserTelemetry(user.id, telemetry);
    saveUserSessions(user.id, sessions);
    saveUserSummary(user.id, summary);
    saveUserDeviceRecord(user.id, deviceRec);

    return res.json({
      status: 'ok',
      received: true,
      ingested: ingestedCount,
      duplicates: duplicateCount,
      totalEvents: telemetry.length,
      user: user.username,
      chunkCount: sessions.length,
      event: telemetry[telemetry.length - 1],
    });
  } catch (e: any) {
    console.error('Error in ingest-event:', e);
    return res.status(500).json({ error: e.message });
  }
});

// Sync full sessions or chronotrace_live.json payload from agent
router.post(['/api/sync-sessions', '/api/agent/sync-file'], (req, res) => {
  try {
    const user = resolveTargetUserForAgent(req);
    if (!user) {
      return res.status(401).json({ error: 'Unrecognized user token. Device not bound to any account.' });
    }

    const payload = req.body || {};
    let inputSessions: any[] = Array.isArray(payload.sessions)
      ? [...payload.sessions]
      : Array.isArray(payload)
      ? [...payload]
      : [];

    // Also include currently active window if present and valid
    if (payload.current && payload.current.appName && payload.current.appName !== 'Waiting...') {
      const cur = payload.current;
      const curTitle = cur.windowTitle || cur.appName;
      const isAlreadyLast = inputSessions.length > 0 &&
        inputSessions[inputSessions.length - 1].appName === cur.appName &&
        inputSessions[inputSessions.length - 1].windowTitle === curTitle;

      if (!isAlreadyLast) {
        inputSessions.push({
          id: `cur-${Date.now()}`,
          appName: cur.appName,
          windowTitle: curTitle,
          category: cur.category || 'Deep Work',
          specificTask: cur.specificTask || `${cur.appName}: ${curTitle}`,
          durationSeconds: Math.max(1, Number(cur.elapsedSeconds) || 2),
          startTime: new Date(cur.timestamp ? cur.timestamp * 1000 : Date.now()).toLocaleTimeString(),
          endTime: new Date().toLocaleTimeString(),
        });
      }
    }

    // Active sync from live agent: synchronize heartbeat with authoritative server time
    const nowIso = new Date().toISOString();
    const nowDate = new Date().toISOString().split('T')[0];
    const rec = getUserDeviceRecord(user.id);

    rec.lastHeartbeatAt = nowIso;
    rec.lastSuccessfulConnectionAt = nowIso;
    rec.connectedSince = rec.connectedSince || nowIso;
    rec.paused = false;

    if (payload.deviceName) rec.deviceName = payload.deviceName;
    if (payload.os) rec.os = payload.os;

    if (inputSessions.length > 0) {
      const telemetry = getUserTelemetry(user.id);
      const existingChunks = getUserSessions(user.id);
      const summary = getUserSummary(user.id);
      const eventIndex = getUserEventIndex(user.id);

      inputSessions.forEach((s: any) => {
        // Disallow synthetic or test events
        if (s.isTest || s.test || s.sourceType === 'synthetic-test' || (typeof s.id === 'string' && (s.id.includes('dummy') || s.id.includes('seed-')))) {
          return;
        }

        const appName = (s.appName || 'Application').trim();
        const winTitle = (s.windowTitle || appName).trim();
        const userPrefs = getUserPreferences(user.id);
        const classification = classifyActivity(appName, winTitle, userPrefs);

        let cat = (s.overrideCategory || classification.category || s.category || 'Unclassified') as string;
        let intent = classification.intent;
        let isCollector = classification.isCollectorProcess || false;
        if (isCollector) {
          cat = 'Utilities';
          intent = 'ADMIN';
        }

        const task = s.specificTask || s.inferredIntent || classification.task || `${appName}: ${winTitle}`;
        const dwellS = Math.max(1, Number(s.durationSeconds) || 2);
        const startTimeStr = s.startTime || new Date().toLocaleTimeString();
        const endTimeStr = s.endTime || startTimeStr;

        const eventId = s.id ? (s.id.startsWith('evt_') ? s.id : `evt_${s.id}`) : `evt_sync_${nowDate}_${appName}_${winTitle}_${startTimeStr}`;
        const eventSig = `${nowDate}:::${startTimeStr}:::${appName}:::${winTitle}`;

        if (eventIndex.has(eventId) || eventIndex.has(eventSig)) {
          return;
        }
        eventIndex.add(eventId);
        eventIndex.add(eventSig);

        // Deduplication key
        const matchChunk = existingChunks.find(
          (c) =>
            (s.id && c.chunk_id === s.id) ||
            (c.anchor_app === appName && c.start_time === startTimeStr) ||
            (c.main_events?.length === 1 &&
              c.main_events[0].app === appName &&
              c.main_events[0].title === winTitle &&
              c.start_time === startTimeStr)
        );

        if (matchChunk) {
          // Update existing chunk with latest duration if still active
          matchChunk.duration_s = dwellS;
          matchChunk.anchor_held_s = dwellS;
          matchChunk.end_time = endTimeStr;
          if (matchChunk.main_events && matchChunk.main_events[0]) {
            matchChunk.main_events[0].dwell_s = dwellS;
          }
          matchChunk.summary = `Captured session: ${appName} - ${winTitle} (${dwellS}s).`;
        } else {
          // New chunk
          const chunkId = s.id || `chk_${eventId}`;
          const isDeep = !isCollector && (
            cat === 'Coding' ||
            cat === 'Work' ||
            cat === 'Study' ||
            cat === 'Research' ||
            cat === 'Deep Work' ||
            cat === 'Learning' ||
            cat === 'Learning & Research'
          );
          const isDist = !isCollector && (cat === 'Entertainment' || cat === 'Distraction');
          const isIdle = cat === 'Idle';
          const chunkEngagement = isIdle ? 0 : Math.min(95, Math.max(70, 75 + Math.min(20, Math.round(dwellS / 60))));

          existingChunks.push({
            chunk_id: chunkId,
            recorded_at: nowIso,
            localDate: nowDate,
            duration_s: dwellS,
            active_duration_s: isIdle ? 0 : dwellS,
            idle_duration_s: isIdle ? dwellS : 0,
            start_time: startTimeStr,
            end_time: endTimeStr,
            closed_by: 'NATURAL_SWITCH',
            main_events: [{
              app: appName,
              title: winTitle,
              dwell_s: dwellS,
              keys: 0,
              active_dwell_s: isIdle ? 0 : dwellS,
              idle_dwell_s: isIdle ? dwellS : 0,
            }],
            anchor_app: appName,
            anchor_held_s: dwellS,
            returned_to_anchor: true,
            engagement_score: chunkEngagement,
            engagement_state: isIdle ? 'idle' : 'active',
            keyboard: { total_keys: 0, rate_per_min: 0 },
            micro_behavior: {
              total_rapid_switches: 1,
              tab_flickers: 0,
              avg_micro_dwell_ms: dwellS * 1000,
              dominant_pattern: 'NORMAL',
              unique_micro_apps: [appName],
            },
            categories_present: [cat],
            dominant_category: cat,
            copy_paste_events: 0,
            session_start_restless: false,
            intent: isCollector ? 'ADMIN' : intent,
            confidence: classification.confidence,
            classification_reason: classification.reason,
            is_collector_process: isCollector,
            primary_task: task,
            distraction_detected: isDist,
            distraction_type: isDist ? 'rabbit_hole' : null,
            work_state: isDeep ? 'productive' : isDist ? 'unsettled' : 'settled',
            unresolved_threads: [],
            summary: `Captured session: ${appName} - ${winTitle} (${dwellS}s).`,
          });

          // Add raw telemetry event
          telemetry.push({
            id: eventId,
            timestamp: startTimeStr,
            date: nowDate,
            recorded_at: nowIso,
            dwell_ms: dwellS * 1000,
            active_dwell_ms: isIdle ? 0 : dwellS * 1000,
            idle_dwell_ms: isIdle ? dwellS * 1000 : 0,
            category: cat,
            confidence: classification.confidence,
            classification_reason: classification.reason,
            is_collector_process: isCollector,
            app_name: appName,
            window_title: winTitle,
            keyboard_events: 0,
            engagement_state: isIdle ? 'idle' : 'active',
          });
        }
      });

      // Recalculate summary metrics from the deduplicated chunks
      let totalTele = 0;
      let totalDeep = 0;
      let totalDist = 0;
      const triggers: Set<string> = new Set();

      existingChunks.forEach((c) => {
        totalTele += c.duration_s || 0;
        if (!c.is_collector_process) {
          if (
            c.dominant_category === 'Coding' ||
            c.dominant_category === 'Work' ||
            c.dominant_category === 'Study' ||
            c.dominant_category === 'Research' ||
            c.dominant_category === 'Deep Work' ||
            c.dominant_category === 'Learning' ||
            c.dominant_category === 'Learning & Research'
          ) {
            totalDeep += c.duration_s || 0;
          } else if (c.dominant_category === 'Entertainment' || c.dominant_category === 'Distraction') {
            totalDist += c.duration_s || 0;
            if (c.primary_task) triggers.add(c.primary_task);
          }
        }
      });

      summary.total_telemetry_s = totalTele;
      summary.total_deep_work_s = totalDeep;
      summary.total_distraction_s = totalDist;
      summary.distraction_triggers = Array.from(triggers);

      if (telemetry.length > 1000) telemetry.splice(0, telemetry.length - 1000);
      if (existingChunks.length > 200) existingChunks.splice(0, existingChunks.length - 200);

      rec.lastEventTime = new Date().toLocaleTimeString();
      rec.lastLocalDate = nowDate;

      saveUserEventIndex(user.id, eventIndex);
      saveUserTelemetry(user.id, telemetry);
      saveUserSessions(user.id, existingChunks);
      saveUserSummary(user.id, summary);
    }

    saveUserDeviceRecord(user.id, rec);
    const telemetry = getUserTelemetry(user.id);
    res.json({
      success: true,
      device: toDeviceStatus(rec, telemetry.length),
      syncedSessions: inputSessions.length,
      totalEvents: telemetry.length,
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Error syncing sessions' });
  }
});


export default router;
