import express from 'express';
import bcrypt from 'bcryptjs';
import { randomBytes } from 'crypto';
import { OAuth2Client, type TokenPayload } from 'google-auth-library';
import type { UserRecord } from '../types/models.js';
import { getUsers, saveUsers, newDeviceToken, getAuthSessions, saveAuthSessions } from '../services/userStore.js';
import {
  getSessionToken,
  getAuthenticatedUser,
  createSessionForUser,
  toUserProfile,
  sessionCookieOptions,
  SESSION_COOKIE_NAME,
} from '../services/authHelpers.js';
import {
  validateRegistration,
  normalizeEmail,
  normalizeUsername,
  type FieldErrors,
} from '../../../shared/validation/auth.js';

const router = express.Router();

const BCRYPT_ROUNDS = 10;
// Compared against when the username is unknown, so a missing account takes about as long
// as a wrong password and the response time does not reveal which usernames exist.
const TIMING_DECOY_HASH = bcrypt.hashSync('chronotrace-timing-decoy', BCRYPT_ROUNDS);
const BCRYPT_PATTERN = /^\$2[aby]\$\d{2}\$[./A-Za-z0-9]{53}$/;
const INVALID_LOGIN = 'Invalid username/email or password.';

const getGoogleClientId = (): string | null => (process.env.GOOGLE_CLIENT_ID || '').trim() || null;

let googleVerifier: OAuth2Client | null = null;
const getGoogleVerifier = (): OAuth2Client => {
  if (!googleVerifier) googleVerifier = new OAuth2Client();
  return googleVerifier;
};

// Checks the stored hash and the typed password. Returns false for a hash that is not
// bcrypt-formatted (for example, a corrupted or hand-edited record) and logs it, so the
// cause is visible in the server log.
const passwordMatches = (candidate: string, user: UserRecord): boolean => {
  if (!BCRYPT_PATTERN.test(user.passwordHash || '')) {
    console.warn(`[auth] account ${user.id} has no valid password hash; password sign-in is unavailable until it is reset.`);
    return false;
  }
  if (bcrypt.compareSync(candidate, user.passwordHash)) return true;
  // Accounts created before the password was no longer trimmed may have a trimmed hash.
  // Accept the trimmed form only when it verifies. The stored hash is never rewritten.
  const trimmed = candidate.trim();
  return trimmed !== candidate && bcrypt.compareSync(trimmed, user.passwordHash);
};

const setSessionCookie = (req: express.Request, res: express.Response, token: string) => {
  res.cookie(SESSION_COOKIE_NAME, token, sessionCookieOptions(req));
};

// -------------------------------------------------------------
// AUTHENTICATION ROUTES
// -------------------------------------------------------------

// Public, non-secret settings the sign-in page needs (the Google client ID is public by design).
router.get('/api/auth/config', (_req, res) => {
  const googleClientId = getGoogleClientId();
  res.json({
    googleClientId,
    googleEnabled: Boolean(googleClientId),
    passwordEnabled: true,
  });
});

router.get('/api/auth/session', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (user) {
    const sessions = getAuthSessions();
    let token = getSessionToken(req) || Object.keys(sessions).find((k) => sessions[k].userId === user.id) || null;
    if (!token) {
      const sess = createSessionForUser(user);
      token = sess.token;
      setSessionCookie(req, res, token);
    }
    return res.json({
      authenticated: true,
      token,
      sessionToken: token,
      isRegistered: user.isRegistered !== false,
      hasConfiguredDevice: user.hasConfiguredDevice !== false,
      user: toUserProfile(user),
    });
  }
  return res.json({
    authenticated: false,
    token: null,
    sessionToken: null,
    isRegistered: false,
    hasConfiguredDevice: false,
    user: null,
  });
});

router.post('/api/auth/login', (req, res) => {
  const body = req.body ?? {};
  if (typeof body.username !== 'string' || typeof body.password !== 'string') {
    return res.status(400).json({ error: 'Enter your username or email and password.' });
  }

  const login = normalizeUsername(body.username);
  if (!login || !body.password) {
    return res.status(400).json({ error: 'Enter your username or email and password.' });
  }

  // Usernames cannot contain "@", so one comparison covers both identifiers.
  const users = getUsers();
  const matched = users.find(
    (u) =>
      (Boolean(u.username) && u.username.toLowerCase() === login) ||
      (Boolean(u.email) && u.email.toLowerCase() === login)
  );

  // An unknown account still runs one bcrypt comparison, so timing does not reveal which usernames exist.
  let valid = false;
  if (matched) {
    valid = passwordMatches(body.password, matched);
  } else {
    bcrypt.compareSync(body.password, TIMING_DECOY_HASH);
  }
  if (!matched || !valid) {
    return res.status(401).json({ error: INVALID_LOGIN });
  }

  matched.lastLogin = new Date().toISOString();
  saveUsers(users);

  const { token } = createSessionForUser(matched);
  setSessionCookie(req, res, token);

  const profile = toUserProfile(matched);
  return res.json({
    success: true,
    token,
    sessionToken: token,
    session: {
      authenticated: true,
      token,
      sessionToken: token,
      isRegistered: matched.isRegistered !== false,
      hasConfiguredDevice: matched.hasConfiguredDevice !== false,
      user: profile,
    },
    user: profile,
    isRegistered: matched.isRegistered !== false,
    hasConfiguredDevice: matched.hasConfiguredDevice !== false,
  });
});

router.post('/api/auth/register', (req, res) => {
  const body = req.body ?? {};
  const result = validateRegistration(body);
  if (!result.valid) {
    const first = Object.values(result.errors)[0] as string;
    return res.status(400).json({ error: first, fieldErrors: result.errors });
  }

  const { name, username, email } = result.values;
  const users = getUsers();
  const conflicts: FieldErrors = {};
  if (users.some((u) => Boolean(u.username) && u.username.toLowerCase() === username.toLowerCase())) {
    conflicts.username = 'That username is already taken. Please choose another.';
  }
  if (users.some((u) => Boolean(u.email) && u.email.toLowerCase() === email.toLowerCase())) {
    conflicts.email = 'An account with this email already exists. Sign in instead.';
  }
  if (Object.keys(conflicts).length > 0) {
    return res.status(409).json({ error: Object.values(conflicts)[0], fieldErrors: conflicts });
  }

  // The password is hashed exactly as typed. It is never trimmed or altered.
  const passwordHash = bcrypt.hashSync(String(body.password), bcrypt.genSaltSync(BCRYPT_ROUNDS));
  const nowIso = new Date().toISOString();
  const newUser: UserRecord = {
    id: `usr_${Date.now()}_${randomBytes(4).toString('hex')}`,
    username,
    email,
    passwordHash,
    name,
    givenName: name.split(' ')[0] || name,
    deviceToken: newDeviceToken(),
    createdAt: nowIso,
    lastLogin: nowIso,
    isRegistered: false,
    hasConfiguredDevice: false,
  };

  users.push(newUser);
  saveUsers(users);

  const { token } = createSessionForUser(newUser);
  setSessionCookie(req, res, token);

  const profile = toUserProfile(newUser);
  return res.status(201).json({
    success: true,
    sessionToken: token,
    session: {
      authenticated: true,
      token,
      sessionToken: token,
      isRegistered: false,
      hasConfiguredDevice: false,
      user: profile,
    },
    user: profile,
    isRegistered: false,
    hasConfiguredDevice: false,
  });
});

router.post('/api/auth/google', async (req, res) => {
  const clientId = getGoogleClientId();
  if (!clientId) {
    return res.status(503).json({
      error: 'Google sign-in is not configured on this server. Add GOOGLE_CLIENT_ID to backend/.env and restart, or sign in with your email and password.',
      code: 'GOOGLE_NOT_CONFIGURED',
    });
  }

  const credential = req.body?.credential;
  if (typeof credential !== 'string' || !credential) {
    return res.status(400).json({ error: 'A Google sign-in credential is required.' });
  }

  // Verify the ID token's signature, expiry, issuer and audience with Google's public keys.
  // The client never supplies a profile; name, email and subject come only from the verified token.
  let payload: TokenPayload | undefined;
  try {
    const ticket = await getGoogleVerifier().verifyIdToken({ idToken: credential, audience: clientId });
    payload = ticket.getPayload();
  } catch (error) {
    console.warn('[auth] Google ID token rejected:', (error as Error).message);
    return res.status(401).json({ error: 'Google sign-in could not be verified. Please try again.' });
  }

  if (!payload?.sub || !payload.email) {
    return res.status(401).json({ error: 'Google account information is incomplete.' });
  }
  if (payload.email_verified !== true) {
    return res.status(401).json({ error: 'Your Google account email is not verified.' });
  }

  const email = normalizeEmail(payload.email);
  const sub = String(payload.sub);
  const users = getUsers();
  const existing = users.find((u) => u.googleSub === sub);
  const nowIso = new Date().toISOString();
  let user: UserRecord;
  let isFirstTime = false;

  if (existing) {
    user = existing;
    user.lastLogin = nowIso;
    if (payload.picture) user.picture = String(payload.picture);
    if (payload.name) user.name = String(payload.name);
    user.givenName = user.name.split(' ')[0] || user.name;
  } else {
    // A password account with this email was not created by Google. Linking it silently
    // would let whoever registered that email first be reached through Google sign-in.
    if (users.some((u) => u.email === email)) {
      return res.status(409).json({
        error: 'An account with this email already exists. Sign in with your username and password instead.',
        code: 'EMAIL_IN_USE',
      });
    }

    isFirstTime = true;
    const base = (email.split('@')[0] || 'user').replace(/[^a-z0-9_]/g, '').slice(0, 16) || 'user';
    let username = base;
    let counter = 1;
    while (users.some((u) => u.username === username)) {
      username = `${base}${counter++}`;
    }

    const displayName = payload.name ? String(payload.name) : username;
    user = {
      id: `usr_g_${randomBytes(12).toString('hex')}`,
      username,
      email,
      // Random hash: a Google-only account cannot be signed into with a password.
      passwordHash: bcrypt.hashSync(randomBytes(32).toString('hex'), BCRYPT_ROUNDS),
      name: displayName,
      givenName: displayName.split(' ')[0] || displayName,
      picture: payload.picture ? String(payload.picture) : undefined,
      googleSub: sub,
      deviceToken: newDeviceToken(),
      createdAt: nowIso,
      lastLogin: nowIso,
      isRegistered: false,
      hasConfiguredDevice: false,
    };
    users.push(user);
  }

  saveUsers(users);

  const { token } = createSessionForUser(user);
  setSessionCookie(req, res, token);

  const profile = toUserProfile(user);
  const isRegistered = !isFirstTime && user.isRegistered !== false;
  const hasConfiguredDevice = !isFirstTime && user.hasConfiguredDevice !== false;
  return res.json({
    success: true,
    session: { authenticated: true, isRegistered, hasConfiguredDevice, user: profile },
    user: profile,
    isRegistered,
    hasConfiguredDevice,
  });
});

router.post('/api/auth/logout', (req, res) => {
  const token = getSessionToken(req);
  if (token) {
    try {
      const sessions = getAuthSessions();
      delete sessions[token];
      saveAuthSessions(sessions);
    } catch (error) {
      // Still clear the cookie so the browser is signed out locally.
      console.error('[auth] could not remove session on logout:', (error as Error).message);
    }
  }
  res.clearCookie(SESSION_COOKIE_NAME, sessionCookieOptions(req));
  res.json({ success: true });
});

router.post('/api/auth/complete-device-setup', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (user) {
    user.isRegistered = true;
    user.hasConfiguredDevice = true;
    saveUsers(getUsers().map((u) => (u.id === user.id ? user : u)));
  }
  res.json({ success: true });
});

export default router;
