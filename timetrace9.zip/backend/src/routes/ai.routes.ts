import express from 'express';
import bcrypt from 'bcryptjs';
import path from 'path';
import fs from 'fs';
import { ai } from '../config/env.js';
import type { ChunkSummary, DailySynthesis, TelemetryEvent, DeviceState } from '../../../shared/types/chronotrace.js';
import type { UserRecord, AuthSession, DeviceRecord } from '../types/models.js';
import { getUsers, saveUsers, getAuthSessions, saveAuthSessions } from '../services/userStore.js';
import { getUserDir, defaultDeviceRecord, HEARTBEAT_TIMEOUT_MS, isAgentLive, getUserDeviceRecord, saveUserDeviceRecord, getUserTelemetry, saveUserTelemetry, getUserSessions, saveUserSessions, getUserSummary, saveUserSummary } from '../services/dataStore.js';
import { getSessionToken, getAuthenticatedUser, createSessionForUser, toUserProfile, toDeviceStatus } from '../services/authHelpers.js';

const router = express.Router();

// Helper to format seconds nicely
function formatDwell(sec: number): string {
  if (sec <= 0) return '0s';
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  if (m > 0 && s > 0) return `${m}m ${s}s`;
  if (m > 0) return `${m}m`;
  return `${s}s`;
}

// -------------------------------------------------------------
// AI ASSISTANT CHAT ENDPOINT (Context Grounded in Real User Activity)
// -------------------------------------------------------------

router.post('/api/assistant/chat', async (req, res) => {
  try {
    const { message, conversationHistory = [] } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required' });
    }

    const user = res.locals.user as UserRecord;
    const summary = getUserSummary(user.id);
    const sessions = getUserSessions(user.id);
    const telemetry = getUserTelemetry(user.id);
    const rec = getUserDeviceRecord(user.id);

    const todayDate = rec.lastLocalDate || new Date().toISOString().split('T')[0];
    const hasData = telemetry.length > 0 || sessions.length > 0;

    // Aggregate sessions by activity domain / category
    const codingSessions: { app: string; task: string; duration: string; dwell_s: number }[] = [];
    const studySessions: { title: string; domain?: string; duration: string; dwell_s: number }[] = [];
    const commSessions: { app: string; task: string; duration: string; dwell_s: number }[] = [];
    const entertainmentSessions: { title: string; duration: string; dwell_s: number }[] = [];
    const utilitySessions: { app: string; task: string; duration: string; dwell_s: number }[] = [];
    const unclassifiedSessions: { app: string; task: string; duration: string; dwell_s: number }[] = [];

    let totalCodingDwell = 0;
    let totalStudyDwell = 0;
    let totalEntertainmentDwell = 0;
    let totalCommDwell = 0;
    let totalActiveDwell = 0;
    let totalIdleDwell = 0;

    for (const s of sessions) {
      const dur = Math.round(s.duration_s);
      const act = Math.round(s.active_duration_s ?? dur);
      const idl = Math.round(s.idle_duration_s ?? 0);
      totalActiveDwell += act;
      totalIdleDwell += idl;

      const item = {
        app: s.anchor_app || 'App',
        title: s.primary_task || s.anchor_app || 'Session',
        task: s.primary_task || s.summary || s.anchor_app || 'Activity',
        domain: s.domain,
        duration: formatDwell(dur),
        dwell_s: dur,
      };

      if (s.dominant_category === 'Deep Work') {
        codingSessions.push(item);
        totalCodingDwell += dur;
      } else if (s.dominant_category === 'Learning & Research' || s.dominant_category === 'Learning') {
        studySessions.push(item);
        totalStudyDwell += dur;
      } else if (s.dominant_category === 'Entertainment' || s.dominant_category === 'Distraction') {
        entertainmentSessions.push(item);
        totalEntertainmentDwell += dur;
      } else if (s.dominant_category === 'Communication') {
        commSessions.push(item);
        totalCommDwell += dur;
      } else if (s.dominant_category === 'Utility / Admin' || s.dominant_category === 'Utility') {
        utilitySessions.push(item);
      } else {
        unclassifiedSessions.push(item);
      }
    }

    // Grounding payload
    const isLive = isAgentLive(rec);
    const structuredAudit = {
      user: { name: user.name, username: user.username },
      date: todayDate,
      device: {
        name: rec.deviceName || 'Windows Workstation',
        status: isLive ? 'Live Connected & Streaming' : 'Disconnected (Historical Audit Records Preserved)',
        isLive,
        lastHeartbeatAt: rec.lastHeartbeatAt,
        lastEventTime: rec.lastEventTime,
      },
      metrics: {
        total_tracked_time: formatDwell(summary.total_telemetry_s || 0),
        measured_active_time: formatDwell(summary.total_active_dwell_s || totalActiveDwell),
        measured_idle_time: formatDwell(summary.total_idle_dwell_s || totalIdleDwell),
        sustained_deep_work: formatDwell(summary.sustained_deep_work_s || summary.total_deep_work_s || totalCodingDwell),
        learning_and_research: formatDwell(summary.total_study_research_s || summary.total_learning_s || totalStudyDwell),
        recorded_distraction: formatDwell(summary.total_distraction_s || totalEntertainmentDwell),
        context_switches: summary.context_switches || 0,
        work_state: summary.work_state || 'AWAITING_ACTIVITY',
        distraction_triggers: summary.distraction_triggers || [],
      },
      activity_breakdown: {
        coding_and_engineering: codingSessions.slice(-10),
        study_and_research: studySessions.slice(-10),
        communication: commSessions.slice(-5),
        entertainment: entertainmentSessions.slice(-5),
        utilities: utilitySessions.slice(-5),
        unclassified: unclassifiedSessions.slice(-5),
      },
      recent_timeline_chunks: sessions.slice(-12).map((s) => ({
        time: `${s.start_time} - ${s.end_time}`,
        app: s.anchor_app,
        category: s.dominant_category,
        task: s.primary_task,
        duration: formatDwell(Math.round(s.duration_s)),
        engagement: s.engagement_state || 'active',
      })),
    };

    // If no GEMINI_API_KEY is configured, provide an analytical grounded response directly
    if (!process.env.GEMINI_API_KEY) {
      if (!hasData) {
        return res.json({
          role: 'assistant',
          content: `Hello ${user.name}! No active telemetry activity has been recorded yet for today (${todayDate}). Once your Windows agent is connected and streaming events, I will analyze your focus sessions, coding projects, and study topics with exact duration timestamps.`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          suggestedFollowUps: [
            'How do I connect my Windows workstation?',
            'What privacy guarantees does ChronoTrace provide?',
          ],
        });
      }

      const lowerQ = message.toLowerCase();
      let fallbackText = '';
      const connectionPrefix = isLive ? 'Live agent streaming' : 'Historical telemetry records (agent currently offline)';
      if (lowerQ.includes('work') || lowerQ.includes('do') || lowerQ.includes('summary') || lowerQ.includes('today')) {
        fallbackText = `Based on your verified activity for ${todayDate} (${connectionPrefix}):\n\n` +
          `• **Total Tracked Time**: ${formatDwell(summary.total_telemetry_s || 0)} (${formatDwell(summary.total_active_dwell_s || totalActiveDwell)} active, ${formatDwell(summary.total_idle_dwell_s || totalIdleDwell)} idle)\n` +
          `• **Focused Work & Study**: ${formatDwell(summary.total_deep_work_s || (totalCodingDwell + totalStudyDwell))}\n` +
          `• **Context Switches**: ${summary.context_switches || 0} transitions detected\n` +
          `• **Distraction**: ${formatDwell(summary.total_distraction_s || 0)} recorded\n\n` +
          `*Recent focus sessions:* ` +
          (sessions.slice(-3).map((s) => `${s.anchor_app}: ${s.primary_task || s.anchor_app} (${formatDwell(Math.round(s.duration_s))})`).join(', ') || 'None recorded yet.');
      } else if (lowerQ.includes('code') || lowerQ.includes('coding') || lowerQ.includes('program')) {
        fallbackText = codingSessions.length > 0
          ? `You spent **${formatDwell(totalCodingDwell)}** in development environments across ${codingSessions.length} recorded sessions: ${codingSessions.map((c) => `${c.app} (${c.task})`).join('; ')}.`
          : `No coding telemetry was recorded in your stream today (${todayDate}).`;
      } else if (lowerQ.includes('study') || lowerQ.includes('learn') || lowerQ.includes('research')) {
        fallbackText = studySessions.length > 0
          ? `You spent **${formatDwell(totalStudyDwell)}** in verified learning and research across ${studySessions.length} sessions: ${studySessions.map((s) => `${s.title} (${s.duration})`).join(', ')}.`
          : `No study or educational documentation sessions were classified in your stream today (${todayDate}).`;
      } else if (lowerQ.includes('distract') || lowerQ.includes('break')) {
        fallbackText = summary.total_distraction_s > 0
          ? `You recorded **${formatDwell(summary.total_distraction_s)}** in entertainment/distraction. Top triggers: ${summary.distraction_triggers?.join(', ') || 'media stream'}.`
          : `0 seconds of distraction were recorded today. Your focus stability was maintained cleanly.`;
      } else {
        fallbackText = `Here is your verified cognitive audit for ${todayDate} (${connectionPrefix}):\n` +
          `• Work State: **${summary.work_state || 'PRODUCTIVE'}**\n` +
          `• Deep Work & Study: **${formatDwell(summary.total_deep_work_s || 0)}**\n` +
          `• Active Engagement: **${formatDwell(summary.total_active_dwell_s || totalActiveDwell)}**\n` +
          `• Transitions: **${summary.context_switches || 0}** application switches.\n\n` +
          `Let me know if you would like details on specific sessions or application dwells!`;
      }

      return res.json({
        role: 'assistant',
        content: fallbackText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedFollowUps: [
          'What did I study or research today?',
          'How much time did I spend coding?',
          'What were my top applications by duration?',
        ],
      });
    }

    const systemPrompt = hasData
      ? `You are ChronoTrace Assistant, a private, intelligent activity reconstruction assistant.
You answer user questions strictly based on their real, captured computer activity from the ChronoTrace Windows Agent today (${todayDate}).

AUTHENTICATED USER: ${user.name} (${user.username})
AUDIT DATA (VERIFIED BY LOCAL TELEMETRY AGENT):
${JSON.stringify(structuredAudit, null, 2)}

CORE OPERATING GUIDELINES:
1. ACCURACY & EVIDENCE GROUNDING:
   - Answer what the user did, studied, coded, and worked on using the exact figures from the audit data.
   - Accurately mention specific application names, window titles, exact durations in minutes/seconds, and intent categories.
   - Do NOT claim tasks were completed or left unfinished without supporting evidence.

2. CLEARLY DISTINGUISH MEASURED FACTS FROM INFERENCES & HISTORICAL FROM LIVE:
   - Current device connection state: ${isLive ? 'LIVE CONNECTED & STREAMING' : 'DEVICE IS CURRENTLY OFFLINE (Viewing historical audit records)'}.
   - If the device is currently offline, explicitly state that you are reviewing historical records from earlier in the day rather than active live telemetry.
   - When citing verified records (e.g. durations, application titles, switch counts, active dwell), present them as measured facts.
   - When information is unavailable (e.g. an activity was Unclassified or occurred offline), explicitly admit that the data was not recorded.

3. PRIVACY GUARANTEES:
   - ChronoTrace NEVER records keystrokes, passwords, clipboard content, screenshots, or private messages.
   - NEVER claim to know private message contents, typed characters, or passwords.`
      : `You are ChronoTrace Assistant.
AUTHENTICATED USER: ${user.name} (${user.username})
STATUS: No computer activity or focus sessions have been recorded yet today (${todayDate}). The Windows agent is not streaming events yet.

GUIDELINES:
- Honestly and clearly state that no computer activity or focus sessions have been recorded yet today.
- Do NOT invent or hallucinate any session data, application names, or durations.
- Explain that once they run the ChronoTrace agent on their Windows machine, their real foreground windows and focus sessions will be reconstructed and ready for analysis.`;

    const contents: any[] = [{ role: 'user', parts: [{ text: systemPrompt }] }];

    if (Array.isArray(conversationHistory)) {
      for (const msg of conversationHistory) {
        if (msg.role === 'user' || msg.role === 'assistant') {
          contents.push({
            role: msg.role === 'user' ? 'user' : 'model',
            parts: [{ text: msg.content }],
          });
        }
      }
    }

    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    let answer = '';
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents,
      });
      answer = response.text || '';
    } catch (genErr: any) {
      console.warn('Gemini generateContent unavailable; using verified analytical response:', genErr?.message || genErr);
    }

    if (!answer) {
      const lowerQ = message.toLowerCase();
      if (!hasData) {
        answer = `Hello ${user.name}! No active telemetry activity has been recorded yet for today (${todayDate}). Once your Windows agent is connected and streaming events, I will analyze your focus sessions, coding projects, and study topics with exact duration timestamps.`;
      } else if (lowerQ.includes('work') || lowerQ.includes('do') || lowerQ.includes('summary') || lowerQ.includes('today')) {
        answer = `Based on your recorded telemetry for today (${todayDate}):\n\n` +
          `• **Total Tracked Time**: ${formatDwell(summary.total_telemetry_s || 0)} (${formatDwell(summary.total_active_dwell_s || totalActiveDwell)} active, ${formatDwell(summary.total_idle_dwell_s || totalIdleDwell)} idle)\n` +
          `• **Focused Work & Study**: ${formatDwell(summary.total_deep_work_s || (totalCodingDwell + totalStudyDwell))}\n` +
          `• **Context Switches**: ${summary.context_switches || 0} transitions detected\n` +
          `• **Distraction**: ${formatDwell(summary.total_distraction_s || 0)} recorded\n\n` +
          `*Recent focus sessions:* ` +
          (sessions.slice(-4).map((s) => `${s.anchor_app}: ${s.primary_task || s.anchor_app} (${formatDwell(Math.round(s.duration_s))})`).join(', ') || 'None recorded yet.');
      } else if (lowerQ.includes('code') || lowerQ.includes('coding') || lowerQ.includes('program')) {
        answer = codingSessions.length > 0
          ? `You spent **${formatDwell(totalCodingDwell)}** in development environments today across ${codingSessions.length} sessions. Key workspaces included: ${codingSessions.map((c) => `${c.app} (${c.task})`).join('; ')}.`
          : `No coding or code editor telemetry was recorded in your stream today (${todayDate}).`;
      } else if (lowerQ.includes('study') || lowerQ.includes('learn') || lowerQ.includes('research')) {
        answer = studySessions.length > 0
          ? `You spent **${formatDwell(totalStudyDwell)}** in verified learning and research across ${studySessions.length} sessions: ${studySessions.map((s) => `${s.title} (${s.duration})`).join(', ')}.`
          : `No study or educational documentation sessions were classified in your stream today (${todayDate}).`;
      } else if (lowerQ.includes('distract') || lowerQ.includes('break')) {
        answer = summary.total_distraction_s > 0
          ? `You recorded **${formatDwell(summary.total_distraction_s)}** in entertainment/distraction. Top triggers: ${summary.distraction_triggers?.join(', ') || 'media stream'}.`
          : `0 seconds of distraction were recorded today. Your focus stability was maintained cleanly.`;
      } else {
        answer = `Here is your verified cognitive audit for today (${todayDate}):\n` +
          `• Work State: **${summary.work_state || 'PRODUCTIVE'}**\n` +
          `• Deep Work & Study: **${formatDwell(summary.total_deep_work_s || 0)}**\n` +
          `• Active Engagement: **${formatDwell(summary.total_active_dwell_s || totalActiveDwell)}**\n` +
          `• Transitions: **${summary.context_switches || 0}** application switches.\n\n` +
          `Let me know if you would like details on specific sessions or application dwells!`;
      }
    }

    // Generate dynamic suggested follow-ups
    const dynamicFollowUps = hasData
      ? [
          'What did I spend the most time studying or coding?',
          'How does my active time compare to my idle time?',
          'What were my longest uninterrupted focus blocks?',
          'What triggered my context switches today?',
        ]
      : [
          'How do I connect my Windows workstation?',
          'What signals does ChronoTrace passively collect?',
          'How does the browser extension measure engagement?',
        ];

    res.json({
      role: 'assistant',
      content: answer,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      suggestedFollowUps: dynamicFollowUps,
    });
  } catch (error: any) {
    console.error('Assistant error:', error);
    res.status(500).json({ error: error.message || 'Error generating assistant response' });
  }
});

router.post('/api/gemini/synthesize-day', async (req, res) => {
  try {
    const user = res.locals.user as UserRecord;
    const sessions = req.body.sessions || getUserSessions(user.id);
    if (!process.env.GEMINI_API_KEY) {
      return res.status(503).json({ error: 'GEMINI_API_KEY not configured' });
    }

    const promptText = `Synthesize full-day cognitive activity from these session chunks:
${JSON.stringify(sessions, null, 2)}

Provide strict JSON output:
- total_deep_work_s: int
- total_distraction_s: int
- fragmentation_score: float 0-10
- peak_focus_window: string
- context_switches: int
- distraction_triggers: array of strings
- daily_narrative: 2-3 sentences narrative
- unfinished_work: array of strings`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: promptText,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    const currentSummary = getUserSummary(user.id);
    const updated = { ...currentSummary, ...parsed };
    saveUserSummary(user.id, updated);
    res.json(updated);
  } catch (error: any) {
    console.error('Gemini day synthesis error:', error);
    res.status(500).json({ error: error.message || 'Gemini error' });
  }
});

export default router;
