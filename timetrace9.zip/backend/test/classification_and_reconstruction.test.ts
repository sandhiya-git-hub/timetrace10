import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { app } from '../src/app.js';
import { DATA_DIR } from '../src/config/env.js';
import {
  getUserTelemetry,
  getUserSessions,
  saveUserTelemetry,
  saveUserSessions,
  saveUserDeviceRecord,
  saveUserSummary,
  saveUserPreferences,
  getUserPreferences,
  saveUserEventIndex,
  getUserEventIndex,
} from '../src/services/dataStore.js';
import { getUsers, saveUsers, newDeviceToken } from '../src/services/userStore.js';
import { createSessionForUser } from '../src/services/authHelpers.js';
import { classifyActivity } from '../../shared/classification/classifier.js';

describe('ChronoTrace Classification, Reconstruction and Analytics Accuracy Suite', () => {
  let server: http.Server;
  let baseUrl: string;

  const testUserId = 'usr_accuracy_test_999';
  const testDeviceToken = newDeviceToken();
  let testSessionToken: string;

  before(async () => {
    // Register test user
    const users = getUsers().filter((u) => u.id !== testUserId);
    users.push({
      id: testUserId,
      username: 'accuracy_tester',
      email: 'tester@chronotrace.local',
      passwordHash: 'dummy',
      name: 'Accuracy Tester',
      givenName: 'Accuracy',
      deviceToken: testDeviceToken,
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString(),
      isRegistered: true,
      hasConfiguredDevice: true,
    });
    saveUsers(users);

    const session = createSessionForUser({
      id: testUserId,
      username: 'accuracy_tester',
      email: 'tester@chronotrace.local',
      deviceToken: testDeviceToken,
      name: 'Accuracy Tester',
      passwordHash: 'dummy',
      createdAt: new Date().toISOString(),
    });
    testSessionToken = session.token;

    // Clean test user directory
    const userDir = path.join(DATA_DIR, 'users', testUserId);
    if (fs.existsSync(userDir)) {
      fs.rmSync(userDir, { recursive: true, force: true });
    }
    saveUserTelemetry(testUserId, []);
    saveUserSessions(testUserId, []);
    saveUserPreferences(testUserId, []);
    saveUserEventIndex(testUserId, new Set());
    saveUserDeviceRecord(testUserId, {
      paused: false,
      deviceName: 'Windows Workstation',
      os: 'Windows 11 64-bit',
      agentVersion: '1.3.0',
      samplingInterval: '500ms',
      lastHeartbeatAt: new Date().toISOString(),
      connectedSince: new Date().toISOString(),
      lastSuccessfulConnectionAt: new Date().toISOString(),
      lastEventTime: null,
      lastLocalDate: null,
    });

    await new Promise<void>((resolve) => {
      server = app.listen(0, '127.0.0.1', () => {
        const addr = server.address() as any;
        baseUrl = `http://127.0.0.1:${addr.port}`;
        resolve();
      });
    });
  });

  after(async () => {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    const users = getUsers().filter((u) => u.id !== testUserId);
    saveUsers(users);
    const userDir = path.join(DATA_DIR, 'users', testUserId);
    if (fs.existsSync(userDir)) {
      fs.rmSync(userDir, { recursive: true, force: true });
    }
  });

  async function apiCall(method: string, endpoint: string, headers: Record<string, string> = {}, body?: any) {
    const res = await fetch(`${baseUrl}${endpoint}`, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
    const text = await res.text();
    let json: any = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {}
    return { status: res.status, body: json };
  }

  function getAuthHeaders() {
    return {
      Authorization: `Bearer ${testSessionToken}`,
      Cookie: `chronotrace_session=${testSessionToken}`,
    };
  }
  const agentHeaders = {
    'X-Device-Token': testDeviceToken,
  };

  // 1. Intelligent Classification Unit Tests
  it('1. Intelligent Classification: accurately distinguishes YouTube educational vs entertainment vs ambiguous', () => {
    // Educational YouTube content
    const eduRes = classifyActivity(
      'Google Chrome',
      'React 19 Architecture and Compiler Deep Dive Tutorial - YouTube'
    );
    assert.equal(eduRes.category, 'Study');
    assert.equal(eduRes.intent, 'LEARNING');
    assert.ok(eduRes.confidence >= 0.85);
    assert.match(eduRes.reason, /tutorial|academic/i);

    // Entertainment / Song / Movie YouTube content (including Tamil film song from user screenshot)
    const entRes = classifyActivity(
      'Google Chrome',
      'Magale | Baththa | Sai Abhyankar | Vijay Sethupathi | Official Video - YouTube'
    );
    assert.equal(entRes.category, 'Entertainment');
    assert.equal(entRes.intent, 'DISTRACTION');
    assert.ok(entRes.confidence >= 0.85);

    // Trailer / Movie clip
    const trailerRes = classifyActivity('Google Chrome', 'Inception Official Movie Trailer - YouTube');
    assert.equal(trailerRes.category, 'Entertainment');

    // Ambiguous YouTube content (home page or no clear signal)
    const ambigRes = classifyActivity('Google Chrome', 'YouTube - Google Chrome');
    assert.equal(ambigRes.category, 'Unclassified');
    assert.equal(ambigRes.intent, 'UNKNOWN');
    assert.ok(ambigRes.confidence <= 0.5);
    assert.match(ambigRes.reason, /insufficient/i);
  });

  it('1b. Social Platform Intelligence: never forces entertainment on Instagram/Reddit/X and distinguishes educational vs distraction vs unclassified', () => {
    // Educational Instagram account (science/research)
    const instaEdu = classifyActivity(
      'Google Chrome',
      'Dr. Andrew Huberman (@hubermanlab) • Neuroscience Research and Sleep Optimization • Instagram',
      [],
      { domain: 'instagram.com', url: 'https://www.instagram.com/hubermanlab/' }
    );
    assert.equal(instaEdu.category, 'Study');
    assert.equal(instaEdu.intent, 'LEARNING');
    assert.ok(instaEdu.confidence >= 0.85);

    // Instagram Entertainment Reels
    const instaReels = classifyActivity(
      'Google Chrome',
      'Viral Funny Cat and Comedy Parody Reels • Instagram',
      [],
      { domain: 'instagram.com', url: 'https://www.instagram.com/reels/' }
    );
    assert.equal(instaReels.category, 'Entertainment');
    assert.equal(instaReels.intent, 'DISTRACTION');

    // Instagram Generic Homepage (insufficient evidence -> Unclassified, NEVER forced to Entertainment)
    const instaGeneric = classifyActivity(
      'Google Chrome',
      'Instagram',
      [],
      { domain: 'instagram.com', url: 'https://www.instagram.com/' }
    );
    assert.equal(instaGeneric.category, 'Unclassified');
    assert.equal(instaGeneric.intent, 'UNKNOWN');
    assert.ok(instaGeneric.confidence <= 0.5);

    // Reddit Machine Learning subreddit (Research)
    const redditMl = classifyActivity(
      'Google Chrome',
      'Transformer Architecture & Deep Learning Papers : r/MachineLearning - Reddit',
      [],
      { domain: 'reddit.com', url: 'https://www.reddit.com/r/MachineLearning/' }
    );
    assert.equal(redditMl.category, 'Research');
    assert.equal(redditMl.intent, 'LEARNING');

    // Reddit Programming subreddit (Coding)
    const redditProg = classifyActivity(
      'Google Chrome',
      'Rust 2024 Edition and Memory Safety in Systems : r/programming - Reddit',
      [],
      { domain: 'reddit.com', url: 'https://www.reddit.com/r/programming/' }
    );
    assert.equal(redditProg.category, 'Coding');
    assert.equal(redditProg.intent, 'DEEP_WORK');

    // Reddit Generic Feed without specific signals -> Unclassified
    const redditGeneric = classifyActivity(
      'Google Chrome',
      'Reddit - Dive into anything',
      [],
      { domain: 'reddit.com', url: 'https://www.reddit.com/' }
    );
    assert.equal(redditGeneric.category, 'Unclassified');
    assert.equal(redditGeneric.intent, 'UNKNOWN');
  });

  it('2. Collector Process Exclusion: excludes ChronoTrace PowerShell collector from deep work', () => {
    const collectorRes = classifyActivity('PowerShell', 'PowerShell - python chronotrace_agent.py');
    assert.equal(collectorRes.category, 'Utilities');
    assert.equal(collectorRes.isCollectorProcess, true);
    assert.match(collectorRes.reason, /excluded from productivity/i);
  });

  it('3. Code editor classification: distinguishes active development from empty/untitled editor', () => {
    const activeCode = classifyActivity('VS Code', 'server.ts - ChronoTrace - Visual Studio Code');
    assert.equal(activeCode.category, 'Coding');
    assert.equal(activeCode.intent, 'DEEP_WORK');
    assert.ok(activeCode.confidence >= 0.85);

    const emptyEditor = classifyActivity('VS Code', 'Visual Studio Code');
    assert.equal(emptyEditor.category, 'Unclassified');
    assert.ok(emptyEditor.confidence < 0.6);
  });

  // 4. Repeated Window Events & Dwell Calculation
  it('4. Repeated window events accumulate dwell without creating duplicate sessions', async () => {
    // Emit initial window event: 10 seconds in VS Code
    const ev1 = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_repeat_1',
      appName: 'VS Code',
      windowTitle: 'analytics.routes.ts - ChronoTrace',
      deltaSeconds: 10,
      localTime: '10:00:00 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    });
    assert.equal(ev1.status, 200);

    // Emit second event in same active window: 15 seconds in VS Code
    const ev2 = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_repeat_2',
      appName: 'VS Code',
      windowTitle: 'analytics.routes.ts - ChronoTrace',
      deltaSeconds: 15,
      localTime: '10:00:10 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    });
    assert.equal(ev2.status, 200);

    const sessions = getUserSessions(testUserId);
    assert.equal(sessions.length, 1);
    assert.equal(sessions[0].duration_s, 25);
    assert.equal(sessions[0].anchor_app, 'VS Code');
    assert.equal(sessions[0].main_events?.length, 1);
    assert.equal(sessions[0].main_events?.[0].dwell_s, 25);

    // Verify raw events are preserved intact
    const telemetry = getUserTelemetry(testUserId);
    assert.equal(telemetry.length, 2);
    assert.equal(telemetry[0].dwell_ms, 10000);
    assert.equal(telemetry[1].dwell_ms, 15000);
  });

  // 5. Collector Process Ingestion & Metrics Exclusion
  it('5. PowerShell ChronoTrace collector events are excluded from deep work and distraction totals', async () => {
    const collectorEv = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_collector_1',
      appName: 'PowerShell',
      windowTitle: 'PowerShell - python chronotrace_agent.py',
      deltaSeconds: 30,
      localTime: '10:00:25 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    });
    assert.equal(collectorEv.status, 200);

    const telem = getUserTelemetry(testUserId);
    const lastTelem = telem[telem.length - 1];
    assert.equal(lastTelem.is_collector_process, true);
    assert.equal(lastTelem.category, 'Utilities');

    // Query summary: total tracked duration should include collector (30s) + VS Code (25s) = 55s,
    // but total_deep_work_s must ONLY be 25s (collector excluded)!
    const summaryRes = await apiCall('GET', '/api/summary?startDate=2026-10-30&endDate=2026-10-30', getAuthHeaders());
    assert.equal(summaryRes.status, 200);
    assert.equal(summaryRes.body.total_telemetry_s, 55);
    assert.equal(summaryRes.body.total_deep_work_s, 25);
    assert.equal(summaryRes.body.total_distraction_s, 0);
  });

  // 6. Rapid Application Switching
  it('6. Rapid application switching transitions sessions without losing raw events', async () => {
    const apps = [
      { app: 'Google Chrome', title: 'React 19 Documentation - Google Chrome', s: 5 },
      { app: 'Slack', title: 'Slack | team-engineering | Acme Corp', s: 8 },
      { app: 'VS Code', title: 'server.ts - ChronoTrace', s: 20 },
    ];

    for (let i = 0; i < apps.length; i++) {
      const res = await apiCall('POST', '/api/ingest-event', agentHeaders, {
        id: `evt_rapid_${i}`,
        appName: apps[i].app,
        windowTitle: apps[i].title,
        deltaSeconds: apps[i].s,
        localTime: `10:01:0${i} AM`,
        localDate: '2026-10-30',
        sourceType: 'os-hook',
      });
      assert.equal(res.status, 200);
    }

    const telemetry = getUserTelemetry(testUserId);
    assert.ok(telemetry.length >= 6);

    const summaryRes = await apiCall('GET', '/api/summary?startDate=2026-10-30&endDate=2026-10-30', getAuthHeaders());
    assert.ok(summaryRes.body.context_switches >= 3);
  });

  // 7. Duplicate Prevention (Idempotency)
  it('7. Submitting duplicate event twice is rejected and does not double durations', async () => {
    const dupPayload = {
      id: 'evt_exact_unique_123',
      appName: 'VS Code',
      windowTitle: 'dup_test.ts - ChronoTrace',
      deltaSeconds: 50,
      localTime: '10:05:00 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    };

    // First ingestion
    const firstRes = await apiCall('POST', '/api/ingest-event', agentHeaders, dupPayload);
    assert.equal(firstRes.status, 200);
    assert.equal(firstRes.body.ingested, 1);
    assert.equal(firstRes.body.duplicates, 0);

    // Second ingestion with identical ID and signature
    const secondRes = await apiCall('POST', '/api/ingest-event', agentHeaders, dupPayload);
    assert.equal(secondRes.status, 200);
    assert.equal(secondRes.body.ingested, 0);
    assert.equal(secondRes.body.duplicates, 1);
  });

  // 8. User-Controlled Corrections & Preference Persistence
  it('8. User can correct session classification, persisting preference for future matching activities', async () => {
    // 1. Ingest an ambiguous YouTube event that defaults to Unclassified
    const ytAmbigRes = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_ambig_yt_1',
      appName: 'Google Chrome',
      windowTitle: 'Custom Tech Stream - YouTube',
      deltaSeconds: 40,
      localTime: '10:10:00 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    });
    assert.equal(ytAmbigRes.status, 200);

    const sessions = getUserSessions(testUserId);
    const lastSession = sessions[sessions.length - 1];
    assert.equal(lastSession.dominant_category, 'Unclassified');

    // 2. User manually corrects this session to 'Learning & Research' / 'LEARNING'
    const correctRes = await apiCall(
      'POST',
      `/api/sessions/${lastSession.chunk_id}/correct`,
      getAuthHeaders(),
      { intent: 'LEARNING', category: 'Learning & Research' }
    );
    assert.equal(correctRes.status, 200);
    assert.equal(correctRes.body.success, true);
    assert.equal(correctRes.body.chunk.user_corrected, true);
    assert.equal(correctRes.body.chunk.dominant_category, 'Learning & Research');

    // Verify user preference was persisted
    const prefs = getUserPreferences(testUserId);
    assert.ok(prefs.length > 0);
    assert.equal(prefs[prefs.length - 1].category, 'Learning & Research');

    // 3. Ingest a future event matching the same window title
    const nextEventRes = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_ambig_yt_future_match',
      appName: 'Google Chrome',
      windowTitle: 'Custom Tech Stream - YouTube',
      deltaSeconds: 30,
      localTime: '10:12:00 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    });
    assert.equal(nextEventRes.status, 200);

    // Verify that the new event was automatically classified as Learning & Research from user preference rule
    const telem = getUserTelemetry(testUserId);
    const matchedEv = telem.find((e) => e.id === 'evt_ambig_yt_future_match');
    assert.ok(matchedEv);
    assert.equal(matchedEv?.category, 'Learning & Research');
    assert.equal(matchedEv?.confidence, 1.0);
    assert.match(matchedEv?.classification_reason ?? '', /user classification preference/i);
  });

  // 9. Insufficient Data and Productivity Guardrails
  it('9. Zero and insufficient-data states are handled honestly without false productivity labeling', async () => {
    // Create an isolated user with 0 telemetry
    const zeroUserId = 'usr_zero_test_000';
    const users = getUsers();
    users.push({
      id: zeroUserId,
      username: 'zero_user',
      email: 'zero@chronotrace.local',
      passwordHash: 'dummy',
      name: 'Zero User',
      deviceToken: 'ct_dev_zero_user_tok',
      createdAt: new Date().toISOString(),
      isRegistered: true,
      hasConfiguredDevice: true,
    });
    saveUsers(users);

    const zeroSession = createSessionForUser({
      id: zeroUserId,
      username: 'zero_user',
      email: 'zero@chronotrace.local',
      deviceToken: 'ct_dev_zero_user_tok',
      name: 'Zero User',
      passwordHash: 'dummy',
      createdAt: new Date().toISOString(),
    });

    const res = await apiCall('GET', '/api/summary', { Authorization: `Bearer ${zeroSession.token}` });
    assert.equal(res.status, 200);
    assert.equal(res.body.total_telemetry_s, 0);
    assert.equal(res.body.total_deep_work_s, 0);
    assert.equal(res.body.work_state, 'AWAITING_ACTIVITY');

    // Clean up
    saveUsers(getUsers().filter((u) => u.id !== zeroUserId));
  });

  // 10. Date Range Analytics & Raw Telemetry Date Filtering Regression
  it('10. Analytics date filtering correctly scopes summaries and raw telemetry without cross-date bleeding', async () => {
    // Ingest events across two distinct dates: 2026-10-29 and 2026-10-30
    await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_day1_vscode',
      appName: 'VS Code',
      windowTitle: 'day1.ts - ChronoTrace',
      deltaSeconds: 60,
      localTime: '09:00:00 AM',
      localDate: '2026-10-29',
      sourceType: 'os-hook',
    });

    await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_day2_vscode',
      appName: 'VS Code',
      windowTitle: 'day2.ts - ChronoTrace',
      deltaSeconds: 40,
      localTime: '09:00:00 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    });

    // Query for only 2026-10-29
    const day1Summary = await apiCall(
      'GET',
      '/api/summary?startDate=2026-10-29&endDate=2026-10-29',
      getAuthHeaders()
    );
    assert.equal(day1Summary.status, 200);
    assert.equal(day1Summary.body.total_telemetry_s, 60);

    // Query raw telemetry with date filter for 2026-10-29
    const day1Raw = await apiCall(
      'GET',
      '/api/telemetry/raw?date=2026-10-29',
      getAuthHeaders()
    );
    assert.equal(day1Raw.status, 200);
    assert.equal(day1Raw.body.events.length, 1);
    assert.equal(day1Raw.body.events[0].id, 'evt_day1_vscode');

    // Query 7-day range preset
    const weekSummary = await apiCall('GET', '/api/summary?range=week', getAuthHeaders());
    assert.equal(weekSummary.status, 200);
    assert.ok(weekSummary.body.total_telemetry_s >= 100);
  });

  // 11. Sync-file (chronotrace_live.json) Ingestion Parity & Collector Exclusion
  it('11. Sync-file route applies intelligent classification and excludes PowerShell collector', async () => {
    const syncRes = await apiCall('POST', '/api/agent/sync-file', agentHeaders, {
      sessions: [
        {
          id: 'sync_sess_collector',
          appName: 'PowerShell',
          windowTitle: 'PowerShell - python chronotrace_agent.py',
          durationSeconds: 45,
          startTime: '11:00:00 AM',
          endTime: '11:00:45 AM',
        },
        {
          id: 'sync_sess_yt_edu',
          appName: 'Google Chrome',
          windowTitle: 'TypeScript 5 Deep Dive Course - YouTube',
          durationSeconds: 120,
          startTime: '11:01:00 AM',
          endTime: '11:03:00 AM',
        },
      ],
      deviceName: 'Windows Laptop',
      os: 'Windows 11',
    });
    assert.equal(syncRes.status, 200);

    const telem = getUserTelemetry(testUserId);
    const collectorEv = telem.find((e) => e.id?.includes('sync_sess_collector'));
    assert.ok(collectorEv);
    assert.equal(collectorEv?.is_collector_process, true);
    assert.equal(collectorEv?.category, 'Utilities');

    const eduEv = telem.find((e) => e.id?.includes('sync_sess_yt_edu'));
    assert.ok(eduEv);
    assert.equal(eduEv?.category, 'Study');
    assert.ok((eduEv?.confidence ?? 0) >= 0.85);
  });

  // 12. Immutability of Raw Telemetry upon User Correction
  it('12. User classification corrections do not mutate or overwrite original raw telemetry', async () => {
    // Find raw telemetry before correction
    const telemBefore = getUserTelemetry(testUserId);
    const targetRaw = telemBefore.find((e) => e.id === 'evt_ambig_yt_1');
    assert.ok(targetRaw);
    assert.equal(targetRaw?.category, 'Unclassified');

    // Verify raw telemetry retained original category even though session was corrected to Learning
    const telemAfter = getUserTelemetry(testUserId);
    const targetRawAfter = telemAfter.find((e) => e.id === 'evt_ambig_yt_1');
    assert.equal(targetRawAfter?.category, 'Unclassified');
  });

  // 13. Critical Activity Intelligence Verification
  it('13. Explicitly verifies Calendar, Claude, Google AI Studio, GitHub, and Idle classification rules', () => {
    // 13a. Google Calendar must be Productivity & Planning
    const calendarRes = classifyActivity('Google Chrome', 'Google Calendar - Week of Oct 30, 2026', [], {
      domain: 'calendar.google.com',
      url: 'https://calendar.google.com/calendar/u/0/r',
    });
    assert.equal(calendarRes.category, 'Productivity & Planning');
    assert.ok(calendarRes.confidence >= 0.90);

    // 13b. Claude: must NOT automatically become Deep Work
    // Coding context -> Coding
    const claudeCoding = classifyActivity('Google Chrome', 'Refactoring TypeScript Backend Express Routes - Claude', [], {
      domain: 'claude.ai',
      url: 'https://claude.ai/chat/abc123',
    });
    assert.equal(claudeCoding.category, 'Coding');

    // Research context -> Research
    const claudeResearch = classifyActivity('Google Chrome', 'Analysis of Quantum Computing Papers and Literature - Claude', [], {
      domain: 'claude.ai',
      url: 'https://claude.ai/chat/def456',
    });
    assert.equal(claudeResearch.category, 'Research');

    // Generic Claude chat -> Unclassified (never blindly forced to Deep Work)
    const claudeGeneric = classifyActivity('Google Chrome', 'New Chat - Claude', [], {
      domain: 'claude.ai',
      url: 'https://claude.ai/new',
    });
    assert.equal(claudeGeneric.category, 'Unclassified');
    assert.ok(claudeGeneric.confidence <= 0.50);

    // 13c. Google AI Studio: must NOT automatically become Deep Work
    // Coding API context -> Coding
    const aiStudioCoding = classifyActivity('Google Chrome', 'Gemini 2.5 Flash System Instructions and Function Calling API - Google AI Studio', [], {
      domain: 'aistudio.google.com',
      url: 'https://aistudio.google.com/prompts/new_chat',
    });
    assert.equal(aiStudioCoding.category, 'Coding');

    // Generic AI Studio overview -> Unclassified
    const aiStudioGeneric = classifyActivity('Google Chrome', 'Google AI Studio', [], {
      domain: 'aistudio.google.com',
      url: 'https://aistudio.google.com/',
    });
    assert.equal(aiStudioGeneric.category, 'Unclassified');
    assert.ok(aiStudioGeneric.confidence <= 0.50);

    // 13d. GitHub: repo/PR -> Coding; generic feed -> Unclassified
    const githubRepo = classifyActivity('Google Chrome', 'sandhiya-git-hub/timetrace: Activity tracking engine · GitHub', [], {
      domain: 'github.com',
      url: 'https://github.com/sandhiya-git-hub/timetrace',
    });
    assert.equal(githubRepo.category, 'Coding');

    const githubHome = classifyActivity('Google Chrome', 'GitHub', [], {
      domain: 'github.com',
      url: 'https://github.com/',
    });
    assert.equal(githubHome.category, 'Unclassified');

    // 13e. Idle state: inactive user with no interaction -> Idle
    const idleRes = classifyActivity('VS Code', 'analytics.routes.ts - ChronoTrace - Visual Studio Code', [], {
      isIdle: true,
      idleDwellMs: 60000,
      activeDwellMs: 0,
      clickCount: 0,
      scrollCount: 0,
      keyCount: 0,
    });
    assert.equal(idleRes.category, 'Idle');
    assert.equal(idleRes.engagementState, 'idle');
  });
});
