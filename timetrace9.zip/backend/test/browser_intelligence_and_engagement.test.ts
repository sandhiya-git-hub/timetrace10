import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { app } from '../src/app.js';
import { DATA_DIR } from '../src/config/env.js';
import {
  getUserTelemetry,
  getUserSessions,
  saveUserTelemetry,
  saveUserSessions,
  saveUserDeviceRecord,
  saveUserSummary,
  saveUserPreferences,
  saveUserEventIndex,
} from '../src/services/dataStore.js';
import { getUsers, saveUsers, newDeviceToken } from '../src/services/userStore.js';
import { createSessionForUser } from '../src/services/authHelpers.js';
import { classifyActivity } from '../../shared/classification/classifier.js';

describe('ChronoTrace Browser Intelligence, Engagement & Timeline Suite', () => {
  let server: http.Server;
  let baseUrl: string;

  const testUserId = 'usr_browser_intel_test_888';
  const testDeviceToken = newDeviceToken();
  let testSessionToken: string;

  before(async () => {
    // Register test user
    const users = getUsers().filter((u) => u.id !== testUserId);
    users.push({
      id: testUserId,
      username: 'browser_intel_tester',
      email: 'intel_tester@chronotrace.local',
      passwordHash: 'dummy',
      name: 'Browser Intel Tester',
      givenName: 'Intel',
      deviceToken: testDeviceToken,
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString(),
      isRegistered: true,
      hasConfiguredDevice: true,
    });
    saveUsers(users);

    const session = createSessionForUser({
      id: testUserId,
      username: 'browser_intel_tester',
      email: 'intel_tester@chronotrace.local',
      deviceToken: testDeviceToken,
      name: 'Browser Intel Tester',
      passwordHash: 'dummy',
      createdAt: new Date().toISOString(),
    });
    testSessionToken = session.token;

    // Clean test user data directory
    const userDir = path.join(DATA_DIR, 'users', testUserId);
    if (fs.existsSync(userDir)) {
      fs.rmSync(userDir, { recursive: true, force: true });
    }
    saveUserTelemetry(testUserId, []);
    saveUserSessions(testUserId, []);
    saveUserPreferences(testUserId, []);
    saveUserEventIndex(testUserId, new Set());
    saveUserDeviceRecord(testUserId, {
      paused: false,
      deviceName: 'Chrome OS Workstation',
      os: 'Windows 11 64-bit',
      agentVersion: '1.4.0',
      samplingInterval: '500ms',
      lastHeartbeatAt: new Date().toISOString(),
      connectedSince: new Date().toISOString(),
      lastSuccessfulConnectionAt: new Date().toISOString(),
      lastEventTime: null,
      lastLocalDate: null,
    });

    await new Promise<void>((resolve) => {
      server = app.listen(0, '127.0.0.1', () => {
        const addr = server.address() as any;
        baseUrl = `http://127.0.0.1:${addr.port}`;
        resolve();
      });
    });
  });

  after(async () => {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    const users = getUsers().filter((u) => u.id !== testUserId);
    saveUsers(users);
    const userDir = path.join(DATA_DIR, 'users', testUserId);
    if (fs.existsSync(userDir)) {
      fs.rmSync(userDir, { recursive: true, force: true });
    }
  });

  async function apiCall(method: string, endpoint: string, headers: Record<string, string> = {}, body?: any) {
    const res = await fetch(`${baseUrl}${endpoint}`, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
    const text = await res.text();
    let json: any = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {}
    return { status: res.status, headers: res.headers, text, body: json };
  }

  function getAuthHeaders() {
    return {
      Authorization: `Bearer ${testSessionToken}`,
      Cookie: `chronotrace_session=${testSessionToken}`,
    };
  }
  const agentHeaders = {
    'X-Device-Token': testDeviceToken,
  };

  // 1. Browser-Level Telemetry Ingestion
  it('1. Browser Telemetry Ingestion: captures active tab URL, domain, title, tabId and visibility', async () => {
    const res = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_browser_doc_1',
      appName: 'Google Chrome',
      windowTitle: 'Array.prototype.map() - JavaScript | MDN',
      url: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/map',
      domain: 'developer.mozilla.org',
      page_title: 'Array.prototype.map() - JavaScript | MDN',
      tab_id: 101,
      is_active_tab: true,
      page_visible: true,
      scroll_count: 5,
      click_count: 2,
      key_count: 0,
      active_dwell_ms: 18000,
      idle_dwell_ms: 2000,
      deltaSeconds: 20,
      localTime: '02:00:00 PM',
      localDate: '2026-10-30',
      sourceType: 'browser-extension',
    });
    assert.equal(res.status, 200);

    const telem = getUserTelemetry(testUserId);
    assert.equal(telem.length, 1);
    const ev = telem[0];
    assert.equal(ev.domain, 'developer.mozilla.org');
    assert.equal(ev.url, 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/map');
    assert.equal(ev.tab_id, 101);
    assert.equal(ev.is_active_tab, true);
    assert.equal(ev.category, 'Research');
    assert.equal(ev.engagement_state, 'engaged');
    assert.equal(ev.scroll_count, 5);
    assert.equal(ev.click_count, 2);
    assert.equal(ev.key_count, 0);
  });

  // 2. Distinguish Usage from Mere Opening (open_only detection)
  it('2. Distinguish Opening from Usage: brief open with 0 interactions is classified as open_only, not productive work', () => {
    // User opened GitHub PR but immediately switched away after 2s without touching keyboard or mouse
    const openOnlyRes = classifyActivity('Google Chrome', 'Pull Request #42 · sandhiya-git-hub/timetrace - GitHub', [], {
      url: 'https://github.com/sandhiya-git-hub/timetrace/pull/42',
      domain: 'github.com',
      clickCount: 0,
      scrollCount: 0,
      keyCount: 0,
      activeDwellMs: 1000,
      idleDwellMs: 1000,
      durationSeconds: 2,
    });
    assert.equal(openOnlyRes.engagementState, 'open_only');
    assert.equal(openOnlyRes.category, 'Unclassified');
    assert.equal(openOnlyRes.intent, 'UNKNOWN');
    assert.ok(openOnlyRes.confidence <= 0.45);
    assert.match(openOnlyRes.reason, /opened briefly without/i);

    // In contrast, user actively engaged in GitHub with scrolls and clicks
    const engagedRes = classifyActivity('Google Chrome', 'Pull Request #42 · sandhiya-git-hub/timetrace - GitHub', [], {
      url: 'https://github.com/sandhiya-git-hub/timetrace/pull/42',
      domain: 'github.com',
      clickCount: 4,
      scrollCount: 8,
      keyCount: 15,
      activeDwellMs: 25000,
      idleDwellMs: 0,
      durationSeconds: 25,
    });
    assert.equal(engagedRes.engagementState, 'engaged');
    assert.equal(engagedRes.category, 'Coding');
    assert.equal(engagedRes.intent, 'DEEP_WORK');
    assert.ok(engagedRes.confidence >= 0.90);
  });

  // 3. Idle Detection: Open but Idle pages are excluded from productive deep work
  it('3. Idle Detection: docs open in background for 60s without interaction are classified as idle and excluded from focus', async () => {
    const idleEv = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_browser_idle_1',
      appName: 'Google Chrome',
      windowTitle: 'React 19 Hooks API Reference - React',
      url: 'https://react.dev/reference/react',
      domain: 'react.dev',
      click_count: 0,
      scroll_count: 0,
      key_count: 0,
      active_dwell_ms: 0,
      idle_dwell_ms: 60000,
      is_idle: true,
      deltaSeconds: 60,
      localTime: '02:05:00 PM',
      localDate: '2026-10-30',
      sourceType: 'browser-extension',
    });
    assert.equal(idleEv.status, 200);

    const telem = getUserTelemetry(testUserId);
    const last = telem[telem.length - 1];
    assert.equal(last.engagement_state, 'idle');
    assert.ok(last.category === 'Idle' || last.category === 'Unclassified');
    assert.match(last.classification_reason || '', /idle/i);

    // Verify analytics: the 60s idle duration did NOT count toward deep work!
    const summary = await apiCall('GET', '/api/summary?startDate=2026-10-30&endDate=2026-10-30', getAuthHeaders());
    assert.equal(summary.status, 200);
    // Deep work should only include the 18s from the first active test event, not the 60s idle!
    assert.equal(summary.body.total_deep_work_s, 18);
  });

  // 4. Intelligent Classification: Utility / Everyday domains are NOT labeled as Distraction
  it('4. Intelligent Classification: calendar and routine utility sites are classified as Utility / Admin, never distraction', () => {
    const calRes = classifyActivity('Google Chrome', 'Google Calendar - Week of Oct 30', [], {
      url: 'https://calendar.google.com/calendar/u/0/r',
      domain: 'calendar.google.com',
    });
    assert.ok(calRes.category === 'Productivity & Planning' || calRes.category === 'Utility / Admin');
    assert.ok(calRes.intent === 'ADMIN' || calRes.intent === 'DEEP_WORK');
    assert.notEqual(calRes.category, 'Entertainment');
    assert.notEqual(calRes.intent, 'DISTRACTION');

    const mapsRes = classifyActivity('Google Chrome', 'Google Maps - Route to Office', [], {
      url: 'https://maps.google.com/',
      domain: 'maps.google.com',
    });
    assert.ok(mapsRes.category === 'Utilities' || mapsRes.category === 'Utility / Admin');
  });

  // 5. Distraction vs Intentional Break Detection
  it('5. Distraction Detection: short entertainment break after deep work is an Intentional Break, not an unproductive rabbit hole', async () => {
    // Step A: Ingest an active Deep Work session (VS Code for 200s)
    await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_dw_block_1',
      appName: 'VS Code',
      windowTitle: 'server.ts - ChronoTrace',
      deltaSeconds: 200,
      click_count: 20,
      key_count: 140,
      active_dwell_ms: 190000,
      idle_dwell_ms: 10000,
      localTime: '02:10:00 PM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    });

    // Step B: User opens Spotify/YouTube for a 2-minute music break (120s)
    const breakEv = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_music_break_1',
      appName: 'Google Chrome',
      windowTitle: 'Chill Coding Lo-Fi Playlist - YouTube',
      url: 'https://www.youtube.com/watch?v=lofi123',
      domain: 'youtube.com',
      deltaSeconds: 120,
      click_count: 2,
      scroll_count: 1,
      key_count: 0,
      active_dwell_ms: 110000,
      idle_dwell_ms: 10000,
      localTime: '02:13:20 PM',
      localDate: '2026-10-30',
      sourceType: 'browser-extension',
    });
    assert.equal(breakEv.status, 200);

    const sessions = getUserSessions(testUserId);
    const breakSession = sessions[sessions.length - 1];
    assert.ok(breakSession);
    assert.equal(breakSession.break_type, 'intentional_break');
    assert.equal(breakSession.intent, 'DISTRACTION_BREAK');
    assert.equal(breakSession.distraction_detected, false);

    // Summary check: intentional break does not increment total_distraction_s
    const summary = await apiCall('GET', '/api/summary?startDate=2026-10-30&endDate=2026-10-30', getAuthHeaders());
    assert.equal(summary.status, 200);
    assert.equal(summary.body.total_distraction_s, 0);
  });

  // 6. Repeated Page Revisits Tracking
  it('6. Page Revisit Tracking: detects when a domain is revisited multiple times', async () => {
    // Ingest first visit to Stack Overflow
    await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_so_visit_1',
      appName: 'Google Chrome',
      windowTitle: 'javascript - How does event loop work? - Stack Overflow',
      url: 'https://stackoverflow.com/questions/12345',
      domain: 'stackoverflow.com',
      deltaSeconds: 40,
      click_count: 3,
      scroll_count: 5,
      active_dwell_ms: 35000,
      localTime: '02:20:00 PM',
      localDate: '2026-10-30',
      sourceType: 'browser-extension',
    });

    // Ingest second visit to same domain later
    await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'evt_so_visit_2',
      appName: 'Google Chrome',
      windowTitle: 'typescript - Type error TS1192 - Stack Overflow',
      url: 'https://stackoverflow.com/questions/67890',
      domain: 'stackoverflow.com',
      deltaSeconds: 45,
      click_count: 2,
      scroll_count: 6,
      active_dwell_ms: 40000,
      localTime: '02:25:00 PM',
      localDate: '2026-10-30',
      sourceType: 'browser-extension',
    });

    const telem = getUserTelemetry(testUserId);
    const secondVisit = telem.find((e) => e.id === 'evt_so_visit_2');
    assert.ok(secondVisit);
    assert.equal(secondVisit?.revisited, true);
    assert.ok((secondVisit?.revisit_count ?? 0) >= 2);
  });

  // 7. Dynamic Extension Package Download
  it('7. Extension Package Download: dynamically injects server URL and device token into background.js', async () => {
    const res = await apiCall('GET', `/api/download-extension?token=${testDeviceToken}`);
    assert.equal(res.status, 200);
    assert.equal(res.headers.get('content-type'), 'application/zip');
    assert.ok(res.headers.get('content-disposition')?.includes('chronotrace-browser-extension.zip'));
  });
});
